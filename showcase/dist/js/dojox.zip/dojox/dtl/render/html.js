/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


if(!dojo._hasResource["dojox.dtl.render.html"]){
dojo._hasResource["dojox.dtl.render.html"]=true;
dojo.provide("dojox.dtl.render.html");
dojo.require("dojox.dtl.render.dom");
dojox.dtl.render.html.Render=dojox.dtl.render.dom.Render;
}
