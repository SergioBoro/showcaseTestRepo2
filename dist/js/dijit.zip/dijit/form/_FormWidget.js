//>>built
define("dijit/form/_FormWidget",["dojo/_base/declare","dojo/_base/kernel","../_Widget","../_CssStateMixin","../_TemplatedMixin","./_FormWidgetMixin"],function(_1,_2,_3,_4,_5,_6){
if(dojo&&dojo.ready&&!dojo.isAsync){
dojo.ready(0,function(){
var _7=["dijit/form/_FormValueWidget"];
require(_7);
});
}
return _1("dijit.form._FormWidget",[_3,_5,_4,_6],{setDisabled:function(_8){
_2.deprecated("setDisabled("+_8+") is deprecated. Use set('disabled',"+_8+") instead.","","2.0");
this.set("disabled",_8);
},setValue:function(_9){
_2.deprecated("dijit.form._FormWidget:setValue("+_9+") is deprecated.  Use set('value',"+_9+") instead.","","2.0");
this.set("value",_9);
},getValue:function(){
_2.deprecated(this.declaredClass+"::getValue() is deprecated. Use get('value') instead.","","2.0");
return this.get("value");
},postMixInProperties:function(){
this.nameAttrSetting=this.name?("name=\""+this.name.replace(/'/g,"&quot;")+"\""):"";
this.inherited(arguments);
},_setTypeAttr:null});
});
