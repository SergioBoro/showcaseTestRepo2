//>>built
require({cache:{"url:dijit/form/templates/Button.html":"<span class=\"dijit dijitReset dijitInline\" role=\"presentation\"\n\t><span class=\"dijitReset dijitInline dijitButtonNode\"\n\t\tdata-dojo-attach-event=\"ondijitclick:_onClick\" role=\"presentation\"\n\t\t><span class=\"dijitReset dijitStretch dijitButtonContents\"\n\t\t\tdata-dojo-attach-point=\"titleNode,focusNode\"\n\t\t\trole=\"button\" aria-labelledby=\"${id}_label\"\n\t\t\t><span class=\"dijitReset dijitInline dijitIcon\" data-dojo-attach-point=\"iconNode\"></span\n\t\t\t><span class=\"dijitReset dijitToggleButtonIconChar\">&#x25CF;</span\n\t\t\t><span class=\"dijitReset dijitInline dijitButtonText\"\n\t\t\t\tid=\"${id}_label\"\n\t\t\t\tdata-dojo-attach-point=\"containerNode\"\n\t\t\t></span\n\t\t></span\n\t></span\n\t><input ${!nameAttrSetting} type=\"${type}\" value=\"${value}\" class=\"dijitOffScreen\"\n\t\ttabIndex=\"-1\" role=\"presentation\" data-dojo-attach-point=\"valueNode\"\n/></span>\n"}});
define("dijit/form/Button",["require","dojo/_base/declare","dojo/dom-class","dojo/_base/kernel","dojo/_base/lang","./_FormWidget","./_ButtonMixin","dojo/text!./templates/Button.html"],function(_1,_2,_3,_4,_5,_6,_7,_8){
if(dojo&&dojo.ready&&!dojo.isAsync){
dojo.ready(0,function(){
var _9=["dijit/form/DropDownButton","dijit/form/ComboButton","dijit/form/ToggleButton"];
_1(_9);
});
}
return _2("dijit.form.Button",[_6,_7],{showLabel:true,iconClass:"dijitNoIcon",_setIconClassAttr:{node:"iconNode",type:"class"},baseClass:"dijitButton",templateString:_8,_setValueAttr:"valueNode",_onClick:function(e){
var ok=this.inherited(arguments);
if(ok){
if(this.valueNode){
this.valueNode.click();
e.preventDefault();
}
}
return ok;
},_fillContent:function(_a){
if(_a&&(!this.params||!("label" in this.params))){
var _b=_5.trim(_a.innerHTML);
if(_b){
this.label=_b;
}
}
},_setShowLabelAttr:function(_c){
if(this.containerNode){
_3.toggle(this.containerNode,"dijitDisplayNone",!_c);
}
this._set("showLabel",_c);
},setLabel:function(_d){
_4.deprecated("dijit.form.Button.setLabel() is deprecated.  Use set('label', ...) instead.","","2.0");
this.set("label",_d);
},_setLabelAttr:function(_e){
this.inherited(arguments);
if(!this.showLabel&&!("title" in this.params)){
this.titleNode.title=_5.trim(this.containerNode.innerText||this.containerNode.textContent||"");
}
}});
});
