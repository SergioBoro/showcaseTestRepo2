//>>built
define(
//begin v1.x content
({
		previousMessage: "Předchozí volby",
		nextMessage: "Další volby"
})
//end v1.x content
);
