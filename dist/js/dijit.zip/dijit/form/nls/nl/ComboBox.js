//>>built
define(
//begin v1.x content
({
		previousMessage: "Eerdere opties",
		nextMessage: "Meer opties"
})
//end v1.x content
);
