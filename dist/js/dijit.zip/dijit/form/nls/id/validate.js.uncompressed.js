define(
"dijit/form/nls/id/validate", ({
	invalidMessage: "Nilai yang dimasukkan tidak valid.",
	missingMessage: "Nilai ini diperlukan.",
	rangeMessage: "Nilai ini di luar batas."
})
);

