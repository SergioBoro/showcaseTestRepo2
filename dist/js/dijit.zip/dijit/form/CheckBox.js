//>>built
require({cache:{"url:dijit/form/templates/CheckBox.html":"<div class=\"dijit dijitReset dijitInline\" role=\"presentation\"\n\t><input\n\t \t${!nameAttrSetting} type=\"${type}\" ${checkedAttrSetting}\n\t\tclass=\"dijitReset dijitCheckBoxInput\"\n\t\tdata-dojo-attach-point=\"focusNode\"\n\t \tdata-dojo-attach-event=\"onclick:_onClick\"\n/></div>\n"}});
define("dijit/form/CheckBox",["require","dojo/_base/declare","dojo/dom-attr","dojo/query","./ToggleButton","./_CheckBoxMixin","dojo/text!./templates/CheckBox.html"],function(_1,_2,_3,_4,_5,_6,_7){
if(dojo&&dojo.ready&&!dojo.isAsync){
dojo.ready(0,function(){
var _8=["dijit/form/RadioButton"];
_1(_8);
});
}
return _2("dijit.form.CheckBox",[_5,_6],{templateString:_7,baseClass:"dijitCheckBox",_setValueAttr:function(_9,_a){
if(typeof _9=="string"){
this._set("value",_9);
_3.set(this.focusNode,"value",_9);
_9=true;
}
if(this._created){
this.set("checked",_9,_a);
}
},_getValueAttr:function(){
return (this.checked?this.value:false);
},_setIconClassAttr:null,postMixInProperties:function(){
this.inherited(arguments);
this.checkedAttrSetting=this.checked?"checked":"";
},_fillContent:function(){
},_onFocus:function(){
if(this.id){
_4("label[for='"+this.id+"']").addClass("dijitFocusedLabel");
}
this.inherited(arguments);
},_onBlur:function(){
if(this.id){
_4("label[for='"+this.id+"']").removeClass("dijitFocusedLabel");
}
this.inherited(arguments);
}});
});
