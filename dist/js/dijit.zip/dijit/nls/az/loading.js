//>>built
define(
//begin v1.x content
({
	"loadingState" : "Yüklənir...",
	"errorState" : "Problem yarandı"
})
//end v1.x content
);
