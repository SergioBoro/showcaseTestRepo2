//>>built
define("dijit/popup",["dojo/_base/array","dojo/_base/connect","dojo/_base/declare","dojo/dom","dojo/dom-attr","dojo/dom-construct","dojo/dom-geometry","dojo/dom-style","dojo/_base/event","dojo/keys","dojo/_base/lang","dojo/on","dojo/_base/sniff","dojo/_base/window","./place","./BackgroundIframe","."],function(_1,_2,_3,_4,_5,_6,_7,_8,_9,_a,_b,on,_c,_d,_e,_f,_10){
var _11=_3(null,{_stack:[],_beginZIndex:1000,_idGen:1,_createWrapper:function(_12){
var _13=_12._popupWrapper,_14=_12.domNode;
if(!_13){
_13=_6.create("div",{"class":"dijitPopup",style:{display:"none"},role:"presentation"},_d.body());
_13.appendChild(_14);
var s=_14.style;
s.display="";
s.visibility="";
s.position="";
s.top="0px";
_12._popupWrapper=_13;
if(_12.on){
_12.on("destroy",function(){
_6.destroy(_13);
delete _12._popupWrapper;
});
}
}
return _13;
},moveOffScreen:function(_15){
var _16=this._createWrapper(_15);
_8.set(_16,{visibility:"hidden",top:"-9999px",display:""});
},hide:function(_17){
var _18=this._createWrapper(_17);
_8.set(_18,"display","none");
},getTopPopup:function(){
var _19=this._stack;
for(var pi=_19.length-1;pi>0&&_19[pi].parent===_19[pi-1].widget;pi--){
}
return _19[pi];
},open:function(_1a){
var _1b=this._stack,_1c=_1a.popup,_1d=_1a.orient||["below","below-alt","above","above-alt"],ltr=_1a.parent?_1a.parent.isLeftToRight():_7.isBodyLtr(),_1e=_1a.around,id=(_1a.around&&_1a.around.id)?(_1a.around.id+"_dropdown"):("popup_"+this._idGen++);
while(_1b.length&&(!_1a.parent||!_4.isDescendant(_1a.parent.domNode,_1b[_1b.length-1].widget.domNode))){
this.close(_1b[_1b.length-1].widget);
}
var _1f=this._createWrapper(_1c);
_5.set(_1f,{id:id,style:{zIndex:this._beginZIndex+_1b.length},"class":"dijitPopup "+(_1c.baseClass||_1c["class"]||"").split(" ")[0]+"Popup",dijitPopupParent:_1a.parent?_1a.parent.id:""});
if(_c("ie")||_c("mozilla")){
if(!_1c.bgIframe){
_1c.bgIframe=new _f(_1f);
}
}
var _20=_1e?_e.around(_1f,_1e,_1d,ltr,_1c.orient?_b.hitch(_1c,"orient"):null):_e.at(_1f,_1a,_1d=="R"?["TR","BR","TL","BL"]:["TL","BL","TR","BR"],_1a.padding);
_1f.style.display="";
_1f.style.visibility="visible";
_1c.domNode.style.visibility="visible";
var _21=[];
_21.push(on(_1f,_2._keypress,_b.hitch(this,function(evt){
if(evt.charOrCode==_a.ESCAPE&&_1a.onCancel){
_9.stop(evt);
_1a.onCancel();
}else{
if(evt.charOrCode===_a.TAB){
_9.stop(evt);
var _22=this.getTopPopup();
if(_22&&_22.onCancel){
_22.onCancel();
}
}
}
})));
if(_1c.onCancel&&_1a.onCancel){
_21.push(_1c.on("cancel",_1a.onCancel));
}
_21.push(_1c.on(_1c.onExecute?"execute":"change",_b.hitch(this,function(){
var _23=this.getTopPopup();
if(_23&&_23.onExecute){
_23.onExecute();
}
})));
_1b.push({widget:_1c,parent:_1a.parent,onExecute:_1a.onExecute,onCancel:_1a.onCancel,onClose:_1a.onClose,handlers:_21});
if(_1c.onOpen){
_1c.onOpen(_20);
}
return _20;
},close:function(_24){
var _25=this._stack;
while((_24&&_1.some(_25,function(_26){
return _26.widget==_24;
}))||(!_24&&_25.length)){
var top=_25.pop(),_27=top.widget,_28=top.onClose;
if(_27.onClose){
_27.onClose();
}
var h;
while(h=top.handlers.pop()){
h.remove();
}
if(_27&&_27.domNode){
this.hide(_27);
}
if(_28){
_28();
}
}
}});
return (_10.popup=new _11());
});
