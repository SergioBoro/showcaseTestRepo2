//>>built
define("dijit/focus",["dojo/aspect","dojo/_base/declare","dojo/dom","dojo/dom-attr","dojo/dom-construct","dojo/_base/lang","dojo/on","dojo/ready","dojo/_base/sniff","dojo/Stateful","dojo/_base/unload","dojo/_base/window","dojo/window","./a11y","./registry","."],function(_1,_2,_3,_4,_5,_6,on,_7,_8,_9,_a,_b,_c,_d,_e,_f){
var _10=_2([_9,on.Evented],{curNode:null,activeStack:[],constructor:function(){
var _11=_6.hitch(this,function(_12){
if(_3.isDescendant(this.curNode,_12)){
this.set("curNode",null);
}
if(_3.isDescendant(this.prevNode,_12)){
this.set("prevNode",null);
}
});
_1.before(_5,"empty",_11);
_1.before(_5,"destroy",_11);
},registerIframe:function(_13){
return this.registerWin(_13.contentWindow,_13);
},unregisterIframe:function(_14){
this.unregisterWin(_14);
},registerWin:function(_15,_16){
var _17=this;
var _18=function(evt){
_17._justMouseDowned=true;
setTimeout(function(){
_17._justMouseDowned=false;
},0);
if(_8("ie")&&evt&&evt.srcElement&&evt.srcElement.parentNode==null){
return;
}
_17._onTouchNode(_16||evt.target||evt.srcElement,"mouse");
};
var doc=_8("ie")?_15.document.documentElement:_15.document;
if(doc){
if(_8("ie")){
_15.document.body.attachEvent("onmousedown",_18);
var _19=function(evt){
var tag=evt.srcElement.tagName.toLowerCase();
if(tag=="#document"||tag=="body"){
return;
}
if(_d.isTabNavigable(evt.srcElement)){
_17._onFocusNode(_16||evt.srcElement);
}else{
_17._onTouchNode(_16||evt.srcElement);
}
};
doc.attachEvent("onactivate",_19);
var _1a=function(evt){
_17._onBlurNode(_16||evt.srcElement);
};
doc.attachEvent("ondeactivate",_1a);
return function(){
_15.document.detachEvent("onmousedown",_18);
doc.detachEvent("onactivate",_19);
doc.detachEvent("ondeactivate",_1a);
doc=null;
};
}else{
doc.body.addEventListener("mousedown",_18,true);
doc.body.addEventListener("touchstart",_18,true);
var _1b=function(evt){
_17._onFocusNode(_16||evt.target);
};
doc.addEventListener("focus",_1b,true);
var _1c=function(evt){
_17._onBlurNode(_16||evt.target);
};
doc.addEventListener("blur",_1c,true);
return function(){
doc.body.removeEventListener("mousedown",_18,true);
doc.body.removeEventListener("touchstart",_18,true);
doc.removeEventListener("focus",_1b,true);
doc.removeEventListener("blur",_1c,true);
doc=null;
};
}
}
},unregisterWin:function(_1d){
_1d&&_1d();
},_onBlurNode:function(){
this.set("prevNode",this.curNode);
this.set("curNode",null);
if(this._justMouseDowned){
return;
}
if(this._clearActiveWidgetsTimer){
clearTimeout(this._clearActiveWidgetsTimer);
}
this._clearActiveWidgetsTimer=setTimeout(_6.hitch(this,function(){
delete this._clearActiveWidgetsTimer;
this._setStack([]);
this.prevNode=null;
}),100);
},_onTouchNode:function(_1e,by){
if(this._clearActiveWidgetsTimer){
clearTimeout(this._clearActiveWidgetsTimer);
delete this._clearActiveWidgetsTimer;
}
var _1f=[];
try{
while(_1e){
var _20=_4.get(_1e,"dijitPopupParent");
if(_20){
_1e=_e.byId(_20).domNode;
}else{
if(_1e.tagName&&_1e.tagName.toLowerCase()=="body"){
if(_1e===_b.body()){
break;
}
_1e=_c.get(_1e.ownerDocument).frameElement;
}else{
var id=_1e.getAttribute&&_1e.getAttribute("widgetId"),_21=id&&_e.byId(id);
if(_21&&!(by=="mouse"&&_21.get("disabled"))){
_1f.unshift(id);
}
_1e=_1e.parentNode;
}
}
}
}
catch(e){
}
this._setStack(_1f,by);
},_onFocusNode:function(_22){
if(!_22){
return;
}
if(_22.nodeType==9){
return;
}
this._onTouchNode(_22);
if(_22==this.curNode){
return;
}
this.set("curNode",_22);
},_setStack:function(_23,by){
var _24=this.activeStack;
this.set("activeStack",_23);
for(var _25=0;_25<Math.min(_24.length,_23.length);_25++){
if(_24[_25]!=_23[_25]){
break;
}
}
var _26;
for(var i=_24.length-1;i>=_25;i--){
_26=_e.byId(_24[i]);
if(_26){
_26._hasBeenBlurred=true;
_26.set("focused",false);
if(_26._focusManager==this){
_26._onBlur(by);
}
this.emit("widget-blur",_26,by);
}
}
for(i=_25;i<_23.length;i++){
_26=_e.byId(_23[i]);
if(_26){
_26.set("focused",true);
if(_26._focusManager==this){
_26._onFocus(by);
}
this.emit("widget-focus",_26,by);
}
}
},focus:function(_27){
if(_27){
try{
_27.focus();
}
catch(e){
}
}
}});
var _28=new _10();
_7(function(){
var _29=_28.registerWin(_b.doc.parentWindow||_b.doc.defaultView);
if(_8("ie")){
_a.addOnWindowUnload(function(){
_28.unregisterWin(_29);
_29=null;
});
}
});
_f.focus=function(_2a){
_28.focus(_2a);
};
for(var _2b in _28){
if(!/^_/.test(_2b)){
_f.focus[_2b]=typeof _28[_2b]=="function"?_6.hitch(_28,_2b):_28[_2b];
}
}
_28.watch(function(_2c,_2d,_2e){
_f.focus[_2c]=_2e;
});
return _28;
});
