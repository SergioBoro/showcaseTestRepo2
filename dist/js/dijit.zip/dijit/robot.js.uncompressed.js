//>>built
define("dijit/robot", [
	".",
	"dojo/robot"
], function(dijit){
	// module:
	//		dijit/robot
	// summary:
	//		Used to have code needed by robot test harness, but no longer

	return dijit;
});
