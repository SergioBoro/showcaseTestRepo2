//>>built
require({cache:{"url:dijit/layout/templates/AccordionButton.html":"<div data-dojo-attach-event='onclick:_onTitleClick' class='dijitAccordionTitle' role=\"presentation\">\n\t<div data-dojo-attach-point='titleNode,focusNode' data-dojo-attach-event='onkeypress:_onTitleKeyPress'\n\t\t\tclass='dijitAccordionTitleFocus' role=\"tab\" aria-expanded=\"false\"\n\t\t><span class='dijitInline dijitAccordionArrow' role=\"presentation\"></span\n\t\t><span class='arrowTextUp' role=\"presentation\">+</span\n\t\t><span class='arrowTextDown' role=\"presentation\">-</span\n\t\t><img src=\"${_blankGif}\" alt=\"\" class=\"dijitIcon\" data-dojo-attach-point='iconNode' style=\"vertical-align: middle\" role=\"presentation\"/>\n\t\t<span role=\"presentation\" data-dojo-attach-point='titleTextNode' class='dijitAccordionText'></span>\n\t</div>\n</div>\n"}});
define("dijit/layout/AccordionContainer",["require","dojo/_base/array","dojo/_base/declare","dojo/_base/event","dojo/_base/fx","dojo/dom","dojo/dom-attr","dojo/dom-class","dojo/dom-construct","dojo/dom-geometry","dojo/keys","dojo/_base/lang","dojo/on","dojo/_base/sniff","../focus","../_base/manager","../_Widget","../_Container","../_TemplatedMixin","../_CssStateMixin","./StackContainer","./ContentPane","dojo/text!./templates/AccordionButton.html"],function(_1,_2,_3,_4,fx,_5,_6,_7,_8,_9,_a,_b,on,_c,_d,_e,_f,_10,_11,_12,_13,_14,_15){
var _16=_3("dijit.layout._AccordionButton",[_f,_11,_12],{templateString:_15,label:"",_setLabelAttr:{node:"titleTextNode",type:"innerHTML"},title:"",_setTitleAttr:{node:"titleTextNode",type:"attribute",attribute:"title"},iconClassAttr:"",_setIconClassAttr:{node:"iconNode",type:"class"},baseClass:"dijitAccordionTitle",getParent:function(){
return this.parent;
},buildRendering:function(){
this.inherited(arguments);
var _17=this.id.replace(" ","_");
_6.set(this.titleTextNode,"id",_17+"_title");
this.focusNode.setAttribute("aria-labelledby",_6.get(this.titleTextNode,"id"));
_5.setSelectable(this.domNode,false);
},getTitleHeight:function(){
return _9.getMarginSize(this.domNode).h;
},_onTitleClick:function(){
var _18=this.getParent();
_18.selectChild(this.contentWidget,true);
_d.focus(this.focusNode);
},_onTitleKeyPress:function(evt){
return this.getParent()._onKeyPress(evt,this.contentWidget);
},_setSelectedAttr:function(_19){
this._set("selected",_19);
this.focusNode.setAttribute("aria-expanded",_19);
this.focusNode.setAttribute("aria-selected",_19);
this.focusNode.setAttribute("tabIndex",_19?"0":"-1");
}});
var _1a=_3("dijit.layout._AccordionInnerContainer",[_f,_12],{baseClass:"dijitAccordionInnerContainer",isContainer:true,isLayoutContainer:true,buildRendering:function(){
this.domNode=_8.place("<div class='"+this.baseClass+"' role='presentation'>",this.contentWidget.domNode,"after");
var _1b=this.contentWidget,cls=_b.isString(this.buttonWidget)?_b.getObject(this.buttonWidget):this.buttonWidget;
this.button=_1b._buttonWidget=(new cls({contentWidget:_1b,label:_1b.title,title:_1b.tooltip,dir:_1b.dir,lang:_1b.lang,textDir:_1b.textDir,iconClass:_1b.iconClass,id:_1b.id+"_button",parent:this.parent})).placeAt(this.domNode);
this.containerNode=_8.place("<div class='dijitAccordionChildWrapper' style='display:none'>",this.domNode);
_8.place(this.contentWidget.domNode,this.containerNode);
},postCreate:function(){
this.inherited(arguments);
var _1c=this.button;
this._contentWidgetWatches=[this.contentWidget.watch("title",_b.hitch(this,function(_1d,_1e,_1f){
_1c.set("label",_1f);
})),this.contentWidget.watch("tooltip",_b.hitch(this,function(_20,_21,_22){
_1c.set("title",_22);
})),this.contentWidget.watch("iconClass",_b.hitch(this,function(_23,_24,_25){
_1c.set("iconClass",_25);
}))];
},_setSelectedAttr:function(_26){
this._set("selected",_26);
this.button.set("selected",_26);
if(_26){
var cw=this.contentWidget;
if(cw.onSelected){
cw.onSelected();
}
}
},startup:function(){
this.contentWidget.startup();
},destroy:function(){
this.button.destroyRecursive();
_2.forEach(this._contentWidgetWatches||[],function(w){
w.unwatch();
});
delete this.contentWidget._buttonWidget;
delete this.contentWidget._wrapperWidget;
this.inherited(arguments);
},destroyDescendants:function(){
this.contentWidget.destroyRecursive();
}});
var _27=_3("dijit.layout.AccordionContainer",_13,{duration:_e.defaultDuration,buttonWidget:_16,baseClass:"dijitAccordionContainer",buildRendering:function(){
this.inherited(arguments);
this.domNode.style.overflow="hidden";
this.domNode.setAttribute("role","tablist");
},startup:function(){
if(this._started){
return;
}
this.inherited(arguments);
if(this.selectedChildWidget){
var _28=this.selectedChildWidget.containerNode.style;
_28.display="";
_28.overflow="auto";
this.selectedChildWidget._wrapperWidget.set("selected",true);
}
},layout:function(){
var _29=this.selectedChildWidget;
if(!_29){
return;
}
var _2a=_29._wrapperWidget.domNode,_2b=_9.getMarginExtents(_2a),_2c=_9.getPadBorderExtents(_2a),_2d=_29._wrapperWidget.containerNode,_2e=_9.getMarginExtents(_2d),_2f=_9.getPadBorderExtents(_2d),_30=this._contentBox;
var _31=0;
_2.forEach(this.getChildren(),function(_32){
if(_32!=_29){
_31+=_9.getMarginSize(_32._wrapperWidget.domNode).h;
}
});
this._verticalSpace=_30.h-_31-_2b.h-_2c.h-_2e.h-_2f.h-_29._buttonWidget.getTitleHeight();
this._containerContentBox={h:this._verticalSpace,w:this._contentBox.w-_2b.w-_2c.w-_2e.w-_2f.w};
if(_29){
_29.resize(this._containerContentBox);
}
},_setupChild:function(_33){
_33._wrapperWidget=_1a({contentWidget:_33,buttonWidget:this.buttonWidget,id:_33.id+"_wrapper",dir:_33.dir,lang:_33.lang,textDir:_33.textDir,parent:this});
this.inherited(arguments);
},addChild:function(_34,_35){
if(this._started){
var _36=this.containerNode;
if(_35&&typeof _35=="number"){
var _37=_f.prototype.getChildren.call(this);
if(_37&&_37.length>=_35){
_36=_37[_35-1].domNode;
_35="after";
}
}
_8.place(_34.domNode,_36,_35);
if(!_34._started){
_34.startup();
}
this._setupChild(_34);
on.emit(this.id+"-addChild",_34,_35);
this.layout();
if(!this.selectedChildWidget){
this.selectChild(_34);
}
}else{
this.inherited(arguments);
}
},removeChild:function(_38){
if(_38._wrapperWidget){
_8.place(_38.domNode,_38._wrapperWidget.domNode,"after");
_38._wrapperWidget.destroy();
delete _38._wrapperWidget;
}
_7.remove(_38.domNode,"dijitHidden");
this.inherited(arguments);
},getChildren:function(){
return _2.map(this.inherited(arguments),function(_39){
return _39.declaredClass=="dijit.layout._AccordionInnerContainer"?_39.contentWidget:_39;
},this);
},destroy:function(){
if(this._animation){
this._animation.stop();
}
_2.forEach(this.getChildren(),function(_3a){
if(_3a._wrapperWidget){
_3a._wrapperWidget.destroy();
}else{
_3a.destroyRecursive();
}
});
this.inherited(arguments);
},_showChild:function(_3b){
_3b._wrapperWidget.containerNode.style.display="block";
return this.inherited(arguments);
},_hideChild:function(_3c){
_3c._wrapperWidget.containerNode.style.display="none";
this.inherited(arguments);
},_transition:function(_3d,_3e,_3f){
if(_c("ie")<8){
_3f=false;
}
if(this._animation){
this._animation.stop(true);
delete this._animation;
}
var _40=this;
if(_3d){
_3d._wrapperWidget.set("selected",true);
var d=this._showChild(_3d);
if(this.doLayout&&_3d.resize){
_3d.resize(this._containerContentBox);
}
}
if(_3e){
_3e._wrapperWidget.set("selected",false);
if(!_3f){
this._hideChild(_3e);
}
}
if(_3f){
var _41=_3d._wrapperWidget.containerNode,_42=_3e._wrapperWidget.containerNode;
var _43=_3d._wrapperWidget.containerNode,_44=_9.getMarginExtents(_43),_45=_9.getPadBorderExtents(_43),_46=_44.h+_45.h;
_42.style.height=(_40._verticalSpace-_46)+"px";
this._animation=new fx.Animation({node:_41,duration:this.duration,curve:[1,this._verticalSpace-_46-1],onAnimate:function(_47){
_47=Math.floor(_47);
_41.style.height=_47+"px";
_42.style.height=(_40._verticalSpace-_46-_47)+"px";
},onEnd:function(){
delete _40._animation;
_41.style.height="auto";
_3e._wrapperWidget.containerNode.style.display="none";
_42.style.height="auto";
_40._hideChild(_3e);
}});
this._animation.onStop=this._animation.onEnd;
this._animation.play();
}
return d;
},_onKeyPress:function(e,_48){
if(this.disabled||e.altKey||!(_48||e.ctrlKey)){
return;
}
var c=e.charOrCode;
if((_48&&(c==_a.LEFT_ARROW||c==_a.UP_ARROW))||(e.ctrlKey&&c==_a.PAGE_UP)){
this._adjacent(false)._buttonWidget._onTitleClick();
_4.stop(e);
}else{
if((_48&&(c==_a.RIGHT_ARROW||c==_a.DOWN_ARROW))||(e.ctrlKey&&(c==_a.PAGE_DOWN||c==_a.TAB))){
this._adjacent(true)._buttonWidget._onTitleClick();
_4.stop(e);
}
}
}});
if(dojo&&dojo.ready&&!dojo.isAsync){
dojo.ready(0,function(){
var _49=["dijit/layout/AccordionPane"];
_1(_49);
});
}
_27._InnerContainer=_1a;
_27._Button=_16;
return _27;
});
