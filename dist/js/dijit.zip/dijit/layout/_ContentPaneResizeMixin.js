//>>built
define("dijit/layout/_ContentPaneResizeMixin",["dojo/_base/array","dojo/_base/declare","dojo/dom-attr","dojo/dom-class","dojo/dom-geometry","dojo/_base/lang","dojo/query","dojo/_base/sniff","dojo/_base/window","../registry","./utils","../_Contained"],function(_1,_2,_3,_4,_5,_6,_7,_8,_9,_a,_b,_c){
return _2("dijit.layout._ContentPaneResizeMixin",null,{doLayout:true,isContainer:true,isLayoutContainer:true,_startChildren:function(){
_1.forEach(this.getChildren(),function(_d){
if(!_d._started){
_d.startup();
_d._started=true;
}
});
},startup:function(){
if(this._started){
return;
}
var _e=_c.prototype.getParent.call(this);
this._childOfLayoutWidget=_e&&_e.isLayoutContainer;
this._needLayout=!this._childOfLayoutWidget;
this.inherited(arguments);
this._startChildren();
if(this._isShown()){
this._onShow();
}
if(!this._childOfLayoutWidget){
this.connect(_8("ie")?this.domNode:_9.global,"onresize",function(){
this._needLayout=!this._childOfLayoutWidget;
this.resize();
});
}
},_checkIfSingleChild:function(){
var _f=_7("> *",this.containerNode).filter(function(_10){
return _10.tagName!=="SCRIPT";
}),_11=_f.filter(function(_12){
return _3.has(_12,"data-dojo-type")||_3.has(_12,"dojoType")||_3.has(_12,"widgetId");
}),_13=_1.filter(_11.map(_a.byNode),function(_14){
return _14&&_14.domNode&&_14.resize;
});
if(_f.length==_11.length&&_13.length==1){
this._singleChild=_13[0];
}else{
delete this._singleChild;
}
_4.toggle(this.containerNode,this.baseClass+"SingleChild",!!this._singleChild);
},resize:function(_15,_16){
if(!this._wasShown&&this.open!==false){
this._onShow();
}
this._resizeCalled=true;
this._scheduleLayout(_15,_16);
},_scheduleLayout:function(_17,_18){
if(this._isShown()){
this._layout(_17,_18);
}else{
this._needLayout=true;
this._changeSize=_17;
this._resultSize=_18;
}
},_layout:function(_19,_1a){
if(_19){
_5.setMarginBox(this.domNode,_19);
}
var cn=this.containerNode;
if(cn===this.domNode){
var mb=_1a||{};
_6.mixin(mb,_19||{});
if(!("h" in mb)||!("w" in mb)){
mb=_6.mixin(_5.getMarginBox(cn),mb);
}
this._contentBox=_b.marginBox2contentBox(cn,mb);
}else{
this._contentBox=_5.getContentBox(cn);
}
this._layoutChildren();
delete this._needLayout;
},_layoutChildren:function(){
if(this.doLayout){
this._checkIfSingleChild();
}
if(this._singleChild&&this._singleChild.resize){
var cb=this._contentBox||_5.getContentBox(this.containerNode);
this._singleChild.resize({w:cb.w,h:cb.h});
}else{
_1.forEach(this.getChildren(),function(_1b){
if(_1b.resize){
_1b.resize();
}
});
}
},_isShown:function(){
if(this._childOfLayoutWidget){
if(this._resizeCalled&&"open" in this){
return this.open;
}
return this._resizeCalled;
}else{
if("open" in this){
return this.open;
}else{
var _1c=this.domNode,_1d=this.domNode.parentNode;
return (_1c.style.display!="none")&&(_1c.style.visibility!="hidden")&&!_4.contains(_1c,"dijitHidden")&&_1d&&_1d.style&&(_1d.style.display!="none");
}
}
},_onShow:function(){
if(this._needLayout){
this._layout(this._changeSize,this._resultSize);
}
this.inherited(arguments);
this._wasShown=true;
}});
});
