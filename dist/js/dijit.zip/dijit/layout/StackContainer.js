//>>built
define("dijit/layout/StackContainer",["dojo/_base/array","dojo/cookie","dojo/_base/declare","dojo/dom-class","dojo/_base/lang","dojo/on","../registry","../_WidgetBase","./_LayoutWidget","dojo/i18n!../nls/common"],function(_1,_2,_3,_4,_5,on,_6,_7,_8){
_5.extend(_7,{selected:false,closable:false,iconClass:"dijitNoIcon",showTitle:true});
return _3("dijit.layout.StackContainer",_8,{doLayout:true,persist:false,baseClass:"dijitStackContainer",buildRendering:function(){
this.inherited(arguments);
_4.add(this.domNode,"dijitLayoutContainer");
this.containerNode.setAttribute("role","tabpanel");
},postCreate:function(){
this.inherited(arguments);
this.connect(this.domNode,"onkeypress",this._onKeyPress);
},startup:function(){
if(this._started){
return;
}
var _9=this.getChildren();
_1.forEach(_9,this._setupChild,this);
if(this.persist){
this.selectedChildWidget=_6.byId(_2(this.id+"_selectedChild"));
}else{
_1.some(_9,function(_a){
if(_a.selected){
this.selectedChildWidget=_a;
}
return _a.selected;
},this);
}
var _b=this.selectedChildWidget;
if(!_b&&_9[0]){
_b=this.selectedChildWidget=_9[0];
_b.selected=true;
}
on.emit(this.id+"-startup",{children:_9,selected:_b});
this.inherited(arguments);
},resize:function(){
var _c=this.selectedChildWidget;
if(_c&&!this._hasBeenShown){
this._hasBeenShown=true;
this._showChild(_c);
}
this.inherited(arguments);
},_setupChild:function(_d){
this.inherited(arguments);
_4.replace(_d.domNode,"dijitHidden","dijitVisible");
_d.domNode.title="";
},addChild:function(_e,_f){
this.inherited(arguments);
if(this._started){
on.emit(this.id+"-addChild",_e,_f);
this.layout();
if(!this.selectedChildWidget){
this.selectChild(_e);
}
}
},removeChild:function(_10){
this.inherited(arguments);
if(this._started){
on.emit(this.id+"-removeChild",_10);
}
if(this._descendantsBeingDestroyed){
return;
}
if(this.selectedChildWidget===_10){
this.selectedChildWidget=undefined;
if(this._started){
var _11=this.getChildren();
if(_11.length){
this.selectChild(_11[0]);
}
}
}
if(this._started){
this.layout();
}
},selectChild:function(_12,_13){
_12=_6.byId(_12);
if(this.selectedChildWidget!=_12){
var d=this._transition(_12,this.selectedChildWidget,_13);
this._set("selectedChildWidget",_12);
on.emit(this.id+"-selectChild",_12);
if(this.persist){
_2(this.id+"_selectedChild",this.selectedChildWidget.id);
}
}
return d;
},_transition:function(_14,_15){
if(_15){
this._hideChild(_15);
}
var d=this._showChild(_14);
if(_14.resize){
if(this.doLayout){
_14.resize(this._containerContentBox||this._contentBox);
}else{
_14.resize();
}
}
return d;
},_adjacent:function(_16){
var _17=this.getChildren();
var _18=_1.indexOf(_17,this.selectedChildWidget);
_18+=_16?1:_17.length-1;
return _17[_18%_17.length];
},forward:function(){
return this.selectChild(this._adjacent(true),true);
},back:function(){
return this.selectChild(this._adjacent(false),true);
},_onKeyPress:function(e){
on.emit(this.id+"-containerKeyPress",{e:e,page:this});
},layout:function(){
var _19=this.selectedChildWidget;
if(_19&&_19.resize){
if(this.doLayout){
_19.resize(this._containerContentBox||this._contentBox);
}else{
_19.resize();
}
}
},_showChild:function(_1a){
var _1b=this.getChildren();
_1a.isFirstChild=(_1a==_1b[0]);
_1a.isLastChild=(_1a==_1b[_1b.length-1]);
_1a._set("selected",true);
_4.replace(_1a.domNode,"dijitVisible","dijitHidden");
return (_1a._onShow&&_1a._onShow())||true;
},_hideChild:function(_1c){
_1c._set("selected",false);
_4.replace(_1c.domNode,"dijitHidden","dijitVisible");
_1c.onHide&&_1c.onHide();
},closeChild:function(_1d){
var _1e=_1d.onClose(this,_1d);
if(_1e){
this.removeChild(_1d);
_1d.destroyRecursive();
}
},destroyDescendants:function(_1f){
this._descendantsBeingDestroyed=true;
_1.forEach(this.getChildren(),function(_20){
this.removeChild(_20);
_20.destroyRecursive(_1f);
},this);
this._descendantsBeingDestroyed=false;
}});
});
