//>>built
define("dijit/Editor",["dojo/_base/array","dojo/_base/declare","dojo/_base/Deferred","dojo/i18n","dojo/dom-attr","dojo/dom-class","dojo/dom-geometry","dojo/dom-style","dojo/_base/event","dojo/keys","dojo/_base/lang","dojo/on","dojo/_base/sniff","dojo/string","dojo/_base/window","./_base/focus","./_Container","./Toolbar","./ToolbarSeparator","./layout/_LayoutWidget","./form/ToggleButton","./_editor/_Plugin","./_editor/plugins/EnterKeyHandling","./_editor/html","./_editor/range","./_editor/RichText",".","dojo/i18n!./_editor/nls/commands"],function(_1,_2,_3,_4,_5,_6,_7,_8,_9,_a,_b,on,_c,_d,_e,_f,_10,_11,_12,_13,_14,_15,_16,_17,_18,_19,_1a){
var _1b=_2("dijit.Editor",_19,{plugins:null,extraPlugins:null,constructor:function(){
if(!_b.isArray(this.plugins)){
this.plugins=["undo","redo","|","cut","copy","paste","|","bold","italic","underline","strikethrough","|","insertOrderedList","insertUnorderedList","indent","outdent","|","justifyLeft","justifyRight","justifyCenter","justifyFull",_16];
}
this._plugins=[];
this._editInterval=this.editActionInterval*1000;
if(_c("ie")){
this.events.push("onBeforeDeactivate");
this.events.push("onBeforeActivate");
}
},postMixInProperties:function(){
this.setValueDeferred=new _3();
this.inherited(arguments);
},postCreate:function(){
this._steps=this._steps.slice(0);
this._undoedSteps=this._undoedSteps.slice(0);
if(_b.isArray(this.extraPlugins)){
this.plugins=this.plugins.concat(this.extraPlugins);
}
this.inherited(arguments);
this.commands=_4.getLocalization("dijit._editor","commands",this.lang);
if(!this.toolbar){
this.toolbar=new _11({dir:this.dir,lang:this.lang});
this.header.appendChild(this.toolbar.domNode);
}
_1.forEach(this.plugins,this.addPlugin,this);
this.setValueDeferred.callback(true);
_6.add(this.iframe.parentNode,"dijitEditorIFrameContainer");
_6.add(this.iframe,"dijitEditorIFrame");
_5.set(this.iframe,"allowTransparency",true);
if(_c("webkit")){
_8.set(this.domNode,"KhtmlUserSelect","none");
}
this.toolbar.startup();
this.onNormalizedDisplayChanged();
},destroy:function(){
_1.forEach(this._plugins,function(p){
if(p&&p.destroy){
p.destroy();
}
});
this._plugins=[];
this.toolbar.destroyRecursive();
delete this.toolbar;
this.inherited(arguments);
},addPlugin:function(_1c,_1d){
var _1e=_b.isString(_1c)?{name:_1c}:_b.isFunction(_1c)?{ctor:_1c}:_1c;
if(!_1e.setEditor){
var o={"args":_1e,"plugin":null,"editor":this};
if(_1e.name){
if(_15.registry[_1e.name]){
o.plugin=_15.registry[_1e.name](_1e);
}else{
on.emit(_1a._scopeName+".Editor.getPlugin",o);
}
}
if(!o.plugin){
var pc=_1e.ctor||_b.getObject(_1e.name);
if(pc){
o.plugin=new pc(_1e);
}
}
if(!o.plugin){
console.warn("Cannot find plugin",_1c);
return;
}
_1c=o.plugin;
}
if(arguments.length>1){
this._plugins[_1d]=_1c;
}else{
this._plugins.push(_1c);
}
_1c.setEditor(this);
if(_b.isFunction(_1c.setToolbar)){
_1c.setToolbar(this.toolbar);
}
},startup:function(){
},resize:function(_1f){
if(_1f){
_13.prototype.resize.apply(this,arguments);
}
},layout:function(){
var _20=(this._contentBox.h-(this.getHeaderHeight()+this.getFooterHeight()+_7.getPadBorderExtents(this.iframe.parentNode).h+_7.getMarginExtents(this.iframe.parentNode).h));
this.editingArea.style.height=_20+"px";
if(this.iframe){
this.iframe.style.height="100%";
}
this._layoutMode=true;
},_onIEMouseDown:function(e){
var _21;
var b=this.document.body;
var _22=b.clientWidth;
var _23=b.clientHeight;
var _24=b.clientLeft;
var _25=b.offsetWidth;
var _26=b.offsetHeight;
var _27=b.offsetLeft;
if(/^rtl$/i.test(b.dir||"")){
if(_22<_25&&e.x>_22&&e.x<_25){
_21=true;
}
}else{
if(e.x<_24&&e.x>_27){
_21=true;
}
}
if(!_21){
if(_23<_26&&e.y>_23&&e.y<_26){
_21=true;
}
}
if(!_21){
delete this._cursorToStart;
delete this._savedSelection;
if(e.target.tagName=="BODY"){
setTimeout(_b.hitch(this,"placeCursorAtEnd"),0);
}
this.inherited(arguments);
}
},onBeforeActivate:function(){
this._restoreSelection();
},onBeforeDeactivate:function(e){
if(this.customUndo){
this.endEditing(true);
}
if(e.target.tagName!="BODY"){
this._saveSelection();
}
},customUndo:true,editActionInterval:3,beginEditing:function(cmd){
if(!this._inEditing){
this._inEditing=true;
this._beginEditing(cmd);
}
if(this.editActionInterval>0){
if(this._editTimer){
clearTimeout(this._editTimer);
}
this._editTimer=setTimeout(_b.hitch(this,this.endEditing),this._editInterval);
}
},_steps:[],_undoedSteps:[],execCommand:function(cmd){
if(this.customUndo&&(cmd=="undo"||cmd=="redo")){
return this[cmd]();
}else{
if(this.customUndo){
this.endEditing();
this._beginEditing();
}
var r=this.inherited(arguments);
if(this.customUndo){
this._endEditing();
}
return r;
}
},_pasteImpl:function(){
return this._clipboardCommand("paste");
},_cutImpl:function(){
return this._clipboardCommand("cut");
},_copyImpl:function(){
return this._clipboardCommand("copy");
},_clipboardCommand:function(cmd){
var r;
try{
r=this.document.execCommand(cmd,false,null);
if(_c("webkit")&&!r){
throw {code:1011};
}
}
catch(e){
if(e.code==1011){
var sub=_d.substitute,_28={cut:"X",copy:"C",paste:"V"};
alert(sub(this.commands.systemShortcut,[this.commands[cmd],sub(this.commands[_c("mac")?"appleKey":"ctrlKey"],[_28[cmd]])]));
}
r=false;
}
return r;
},queryCommandEnabled:function(cmd){
if(this.customUndo&&(cmd=="undo"||cmd=="redo")){
return cmd=="undo"?(this._steps.length>1):(this._undoedSteps.length>0);
}else{
return this.inherited(arguments);
}
},_moveToBookmark:function(b){
var _29=b.mark;
var _2a=b.mark;
var col=b.isCollapsed;
var r,_2b,_2c,sel;
if(_2a){
if(_c("ie")<9){
if(_b.isArray(_2a)){
_29=[];
_1.forEach(_2a,function(n){
_29.push(_18.getNode(n,this.editNode));
},this);
_e.withGlobal(this.window,"moveToBookmark",_1a,[{mark:_29,isCollapsed:col}]);
}else{
if(_2a.startContainer&&_2a.endContainer){
sel=_18.getSelection(this.window);
if(sel&&sel.removeAllRanges){
sel.removeAllRanges();
r=_18.create(this.window);
_2b=_18.getNode(_2a.startContainer,this.editNode);
_2c=_18.getNode(_2a.endContainer,this.editNode);
if(_2b&&_2c){
r.setStart(_2b,_2a.startOffset);
r.setEnd(_2c,_2a.endOffset);
sel.addRange(r);
}
}
}
}
}else{
sel=_18.getSelection(this.window);
if(sel&&sel.removeAllRanges){
sel.removeAllRanges();
r=_18.create(this.window);
_2b=_18.getNode(_2a.startContainer,this.editNode);
_2c=_18.getNode(_2a.endContainer,this.editNode);
if(_2b&&_2c){
r.setStart(_2b,_2a.startOffset);
r.setEnd(_2c,_2a.endOffset);
sel.addRange(r);
}
}
}
}
},_changeToStep:function(_2d,to){
this.setValue(to.text);
var b=to.bookmark;
if(!b){
return;
}
this._moveToBookmark(b);
},undo:function(){
var ret=false;
if(!this._undoRedoActive){
this._undoRedoActive=true;
this.endEditing(true);
var s=this._steps.pop();
if(s&&this._steps.length>0){
this.focus();
this._changeToStep(s,this._steps[this._steps.length-1]);
this._undoedSteps.push(s);
this.onDisplayChanged();
delete this._undoRedoActive;
ret=true;
}
delete this._undoRedoActive;
}
return ret;
},redo:function(){
var ret=false;
if(!this._undoRedoActive){
this._undoRedoActive=true;
this.endEditing(true);
var s=this._undoedSteps.pop();
if(s&&this._steps.length>0){
this.focus();
this._changeToStep(this._steps[this._steps.length-1],s);
this._steps.push(s);
this.onDisplayChanged();
ret=true;
}
delete this._undoRedoActive;
}
return ret;
},endEditing:function(_2e){
if(this._editTimer){
clearTimeout(this._editTimer);
}
if(this._inEditing){
this._endEditing(_2e);
this._inEditing=false;
}
},_getBookmark:function(){
var b=_e.withGlobal(this.window,_f.getBookmark);
var tmp=[];
if(b&&b.mark){
var _2f=b.mark;
if(_c("ie")<9){
var sel=_18.getSelection(this.window);
if(!_b.isArray(_2f)){
if(sel){
var _30;
if(sel.rangeCount){
_30=sel.getRangeAt(0);
}
if(_30){
b.mark=_30.cloneRange();
}else{
b.mark=_e.withGlobal(this.window,_f.getBookmark);
}
}
}else{
_1.forEach(b.mark,function(n){
tmp.push(_18.getIndex(n,this.editNode).o);
},this);
b.mark=tmp;
}
}
try{
if(b.mark&&b.mark.startContainer){
tmp=_18.getIndex(b.mark.startContainer,this.editNode).o;
b.mark={startContainer:tmp,startOffset:b.mark.startOffset,endContainer:b.mark.endContainer===b.mark.startContainer?tmp:_18.getIndex(b.mark.endContainer,this.editNode).o,endOffset:b.mark.endOffset};
}
}
catch(e){
b.mark=null;
}
}
return b;
},_beginEditing:function(){
if(this._steps.length===0){
this._steps.push({"text":_17.getChildrenHtml(this.editNode),"bookmark":this._getBookmark()});
}
},_endEditing:function(){
var v=_17.getChildrenHtml(this.editNode);
this._undoedSteps=[];
this._steps.push({text:v,bookmark:this._getBookmark()});
},onKeyDown:function(e){
if(!_c("ie")&&!this.iframe&&e.keyCode==_a.TAB&&!this.tabIndent){
this._saveSelection();
}
if(!this.customUndo){
this.inherited(arguments);
return;
}
var k=e.keyCode;
if(e.ctrlKey&&!e.altKey){
if(k==90||k==122){
_9.stop(e);
this.undo();
return;
}else{
if(k==89||k==121){
_9.stop(e);
this.redo();
return;
}
}
}
this.inherited(arguments);
switch(k){
case _a.ENTER:
case _a.BACKSPACE:
case _a.DELETE:
this.beginEditing();
break;
case 88:
case 86:
if(e.ctrlKey&&!e.altKey&&!e.metaKey){
this.endEditing();
if(e.keyCode==88){
this.beginEditing("cut");
setTimeout(_b.hitch(this,this.endEditing),1);
}else{
this.beginEditing("paste");
setTimeout(_b.hitch(this,this.endEditing),1);
}
break;
}
default:
if(!e.ctrlKey&&!e.altKey&&!e.metaKey&&(e.keyCode<_a.F1||e.keyCode>_a.F15)){
this.beginEditing();
break;
}
case _a.ALT:
this.endEditing();
break;
case _a.UP_ARROW:
case _a.DOWN_ARROW:
case _a.LEFT_ARROW:
case _a.RIGHT_ARROW:
case _a.HOME:
case _a.END:
case _a.PAGE_UP:
case _a.PAGE_DOWN:
this.endEditing(true);
break;
case _a.CTRL:
case _a.SHIFT:
case _a.TAB:
break;
}
},_onBlur:function(){
this.inherited(arguments);
this.endEditing(true);
},_saveSelection:function(){
try{
this._savedSelection=this._getBookmark();
}
catch(e){
}
},_restoreSelection:function(){
if(this._savedSelection){
delete this._cursorToStart;
if(_e.withGlobal(this.window,"isCollapsed",_1a)){
this._moveToBookmark(this._savedSelection);
}
delete this._savedSelection;
}
},onClick:function(){
this.endEditing(true);
this.inherited(arguments);
},replaceValue:function(_31){
if(!this.customUndo){
this.inherited(arguments);
}else{
if(this.isClosed){
this.setValue(_31);
}else{
this.beginEditing();
if(!_31){
_31="&nbsp;";
}
this.setValue(_31);
this.endEditing();
}
}
},_setDisabledAttr:function(_32){
var _33=_b.hitch(this,function(){
if((!this.disabled&&_32)||(!this._buttonEnabledPlugins&&_32)){
_1.forEach(this._plugins,function(p){
p.set("disabled",true);
});
}else{
if(this.disabled&&!_32){
_1.forEach(this._plugins,function(p){
p.set("disabled",false);
});
}
}
});
this.setValueDeferred.addCallback(_33);
this.inherited(arguments);
},_setStateClass:function(){
try{
this.inherited(arguments);
if(this.document&&this.document.body){
_8.set(this.document.body,"color",_8.get(this.iframe,"color"));
}
}
catch(e){
}
}});
function _34(_35){
return new _15({command:_35.name});
};
function _36(_37){
return new _15({buttonClass:_14,command:_37.name});
};
_b.mixin(_15.registry,{"undo":_34,"redo":_34,"cut":_34,"copy":_34,"paste":_34,"insertOrderedList":_34,"insertUnorderedList":_34,"indent":_34,"outdent":_34,"justifyCenter":_34,"justifyFull":_34,"justifyLeft":_34,"justifyRight":_34,"delete":_34,"selectAll":_34,"removeFormat":_34,"unlink":_34,"insertHorizontalRule":_34,"bold":_36,"italic":_36,"underline":_36,"strikethrough":_36,"subscript":_36,"superscript":_36,"|":function(){
return new _15({button:new _12(),setEditor:function(_38){
this.editor=_38;
}});
}});
return _1b;
});
