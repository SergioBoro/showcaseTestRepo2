//>>built
define("dijit/place",["dojo/_base/array","dojo/dom-geometry","dojo/_base/kernel","dojo/_base/window","dojo/window","."],function(_1,_2,_3,_4,_5,_6){
function _7(_8,_9,_a,_b){
var _c=_5.getBox();
if(!_8.parentNode||String(_8.parentNode.tagName).toLowerCase()!="body"){
_4.body().appendChild(_8);
}
var _d=null;
_1.some(_9,function(_e){
var _f=_e.corner;
var pos=_e.pos;
var _10=0;
var _11={w:{"L":_c.l+_c.w-pos.x,"R":pos.x-_c.l,"M":_c.w}[_f.charAt(1)],h:{"T":_c.t+_c.h-pos.y,"B":pos.y-_c.t,"M":_c.h}[_f.charAt(0)]};
if(_a){
var res=_a(_8,_e.aroundCorner,_f,_11,_b);
_10=typeof res=="undefined"?0:res;
}
var _12=_8.style;
var _13=_12.display;
var _14=_12.visibility;
if(_12.display=="none"){
_12.visibility="hidden";
_12.display="";
}
var mb=_2.getMarginBox(_8);
_12.display=_13;
_12.visibility=_14;
var _15={"L":pos.x,"R":pos.x-mb.w,"M":Math.max(_c.l,Math.min(_c.l+_c.w,pos.x+(mb.w>>1))-mb.w)}[_f.charAt(1)],_16={"T":pos.y,"B":pos.y-mb.h,"M":Math.max(_c.t,Math.min(_c.t+_c.h,pos.y+(mb.h>>1))-mb.h)}[_f.charAt(0)],_17=Math.max(_c.l,_15),_18=Math.max(_c.t,_16),_19=Math.min(_c.l+_c.w,_15+mb.w),_1a=Math.min(_c.t+_c.h,_16+mb.h),_1b=_19-_17,_1c=_1a-_18;
_10+=(mb.w-_1b)+(mb.h-_1c);
if(_d==null||_10<_d.overflow){
_d={corner:_f,aroundCorner:_e.aroundCorner,x:_17,y:_18,w:_1b,h:_1c,overflow:_10,spaceAvailable:_11};
}
return !_10;
});
if(_d.overflow&&_a){
_a(_8,_d.aroundCorner,_d.corner,_d.spaceAvailable,_b);
}
var l=_2.isBodyLtr(),s=_8.style;
s.top=_d.y+"px";
s[l?"left":"right"]=(l?_d.x:_c.w-_d.x-_d.w)+"px";
s[l?"right":"left"]="auto";
return _d;
};
return (_6.place={at:function(_1d,pos,_1e,_1f){
var _20=_1.map(_1e,function(_21){
var c={corner:_21,pos:{x:pos.x,y:pos.y}};
if(_1f){
c.pos.x+=_21.charAt(1)=="L"?_1f.x:-_1f.x;
c.pos.y+=_21.charAt(0)=="T"?_1f.y:-_1f.y;
}
return c;
});
return _7(_1d,_20);
},around:function(_22,_23,_24,_25,_26){
if(typeof _23=="string"||"offsetWidth" in _23){
_23=_2.position(_23,true);
}
var x=_23.x,y=_23.y,_27="w" in _23?_23.w:(_23.w=_23.width),_28="h" in _23?_23.h:(_3.deprecated("place.around: dijit.place.__Rectangle: { x:"+x+", y:"+y+", height:"+_23.height+", width:"+_27+" } has been deprecated.  Please use { x:"+x+", y:"+y+", h:"+_23.height+", w:"+_27+" }","","2.0"),_23.h=_23.height);
var _29=[];
function _2a(_2b,_2c){
_29.push({aroundCorner:_2b,corner:_2c,pos:{x:{"L":x,"R":x+_27,"M":x+(_27>>1)}[_2b.charAt(1)],y:{"T":y,"B":y+_28,"M":y+(_28>>1)}[_2b.charAt(0)]}});
};
_1.forEach(_24,function(pos){
var ltr=_25;
switch(pos){
case "above-centered":
_2a("TM","BM");
break;
case "below-centered":
_2a("BM","TM");
break;
case "after":
ltr=!ltr;
case "before":
_2a(ltr?"ML":"MR",ltr?"MR":"ML");
break;
case "below-alt":
ltr=!ltr;
case "below":
_2a(ltr?"BL":"BR",ltr?"TL":"TR");
_2a(ltr?"BR":"BL",ltr?"TR":"TL");
break;
case "above-alt":
ltr=!ltr;
case "above":
_2a(ltr?"TL":"TR",ltr?"BL":"BR");
_2a(ltr?"TR":"TL",ltr?"BR":"BL");
break;
default:
_2a(pos.aroundCorner,pos.corner);
}
});
return _7(_22,_29,_26,{w:_27,h:_28});
}});
});
