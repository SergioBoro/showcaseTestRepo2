//>>built
define("dijit/robot",[".","dojo/robot"],function(_1){
return _1;
});
