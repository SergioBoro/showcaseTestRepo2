//>>built
define("dijit/Menu",["require","dojo/_base/array","dojo/_base/declare","dojo/_base/event","dojo/dom","dojo/dom-attr","dojo/dom-geometry","dojo/dom-style","dojo/keys","dojo/_base/lang","dojo/on","dojo/_base/sniff","dojo/_base/window","dojo/window","./popup","./DropDownMenu"],function(_1,_2,_3,_4,_5,_6,_7,_8,_9,_a,on,_b,_c,_d,pm,_e){
if(dojo&&!dojo.isAsync&&dojo.ready){
dojo.ready(0,function(){
var _f=["dijit/MenuItem","dijit/PopupMenuItem","dijit/CheckedMenuItem","dijit/MenuSeparator"];
_1(_f);
});
}
return _3("dijit.Menu",_e,{constructor:function(){
this._bindings=[];
},targetNodeIds:[],contextMenuForWindow:false,leftClickToOpen:false,refocus:true,postCreate:function(){
if(this.contextMenuForWindow){
this.bindDomNode(_c.body());
}else{
_2.forEach(this.targetNodeIds,this.bindDomNode,this);
}
this.inherited(arguments);
},_iframeContentWindow:function(_10){
return _d.get(this._iframeContentDocument(_10))||this._iframeContentDocument(_10)["__parent__"]||(_10.name&&_c.doc.frames[_10.name])||null;
},_iframeContentDocument:function(_11){
return _11.contentDocument||(_11.contentWindow&&_11.contentWindow.document)||(_11.name&&_c.doc.frames[_11.name]&&_c.doc.frames[_11.name].document)||null;
},bindDomNode:function(_12){
_12=_5.byId(_12);
var cn;
if(_12.tagName.toLowerCase()=="iframe"){
var _13=_12,_14=this._iframeContentWindow(_13);
cn=_c.withGlobal(_14,_c.body);
}else{
cn=(_12==_c.body()?_c.doc.documentElement:_12);
}
var _15={node:_12,iframe:_13};
_6.set(_12,"_dijitMenu"+this.id,this._bindings.push(_15));
var _16=_a.hitch(this,function(cn){
return [on(cn,this.leftClickToOpen?"click":"contextmenu",_a.hitch(this,function(evt){
_4.stop(evt);
this._scheduleOpen(evt.target,_13,{x:evt.pageX,y:evt.pageY});
})),on(cn,"keydown",_a.hitch(this,function(evt){
if(evt.shiftKey&&evt.keyCode==_9.F10){
_4.stop(evt);
this._scheduleOpen(evt.target,_13);
}
}))];
});
_15.connects=cn?_16(cn):[];
if(_13){
_15.onloadHandler=_a.hitch(this,function(){
var _17=this._iframeContentWindow(_13);
cn=_c.withGlobal(_17,_c.body);
_15.connects=_16(cn);
});
if(_13.addEventListener){
_13.addEventListener("load",_15.onloadHandler,false);
}else{
_13.attachEvent("onload",_15.onloadHandler);
}
}
},unBindDomNode:function(_18){
var _19;
try{
_19=_5.byId(_18);
}
catch(e){
return;
}
var _1a="_dijitMenu"+this.id;
if(_19&&_6.has(_19,_1a)){
var bid=_6.get(_19,_1a)-1,b=this._bindings[bid],h;
while(h=b.connects.pop()){
h.remove();
}
var _1b=b.iframe;
if(_1b){
if(_1b.removeEventListener){
_1b.removeEventListener("load",b.onloadHandler,false);
}else{
_1b.detachEvent("onload",b.onloadHandler);
}
}
_6.remove(_19,_1a);
delete this._bindings[bid];
}
},_scheduleOpen:function(_1c,_1d,_1e){
if(!this._openTimer){
this._openTimer=setTimeout(_a.hitch(this,function(){
delete this._openTimer;
this._openMyself({target:_1c,iframe:_1d,coords:_1e});
}),1);
}
},_openMyself:function(_1f){
var _20=_1f.target,_21=_1f.iframe,_22=_1f.coords;
if(_22){
if(_21){
var ifc=_7.position(_21,true),_23=this._iframeContentWindow(_21),_24=_c.withGlobal(_23,"_docScroll",dojo);
var cs=_8.getComputedStyle(_21),tp=_8.toPixelValue,_25=(_b("ie")&&_b("quirks")?0:tp(_21,cs.paddingLeft))+(_b("ie")&&_b("quirks")?tp(_21,cs.borderLeftWidth):0),top=(_b("ie")&&_b("quirks")?0:tp(_21,cs.paddingTop))+(_b("ie")&&_b("quirks")?tp(_21,cs.borderTopWidth):0);
_22.x+=ifc.x+_25-_24.x;
_22.y+=ifc.y+top-_24.y;
}
}else{
_22=_7.position(_20,true);
_22.x+=10;
_22.y+=10;
}
var _26=this;
var _27=this._focusManager.get("prevNode");
var _28=this._focusManager.get("curNode");
var _29=!_28||(_5.isDescendant(_28,this.domNode))?_27:_28;
function _2a(){
if(_26.refocus&&_29){
_29.focus();
}
pm.close(_26);
};
pm.open({popup:this,x:_22.x,y:_22.y,onExecute:_2a,onCancel:_2a,orient:this.isLeftToRight()?"L":"R"});
this.focus();
this._onBlur=function(){
this.inherited("_onBlur",arguments);
pm.close(this);
};
},uninitialize:function(){
_2.forEach(this._bindings,function(b){
if(b){
this.unBindDomNode(b.node);
}
},this);
this.inherited(arguments);
}});
});
