define({
	popupLabel: "Afișarea sau ascunderea coloanelor"
});