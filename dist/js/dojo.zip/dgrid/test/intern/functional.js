define([
	'./functional/Keyboard',
	'./functional/KeyboardTab'
], function(){});