/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/fx",["./_base/lang","./_base/kernel","./_base/array","./_base/connect","./_base/fx","./dom","./dom-style","./dom-geometry","require"],function(_1,_2,_3,_4,_5,_6,_7,_8,_9){
if(_2&&_2.ready&&!_2.isAsync){
_2.ready(0,function(){
var _a=["./fx/Toggler"];
_9(_a);
});
}
var _b={};
_2.fx=_5;
var _c={_fire:function(_d,_e){
if(this[_d]){
this[_d].apply(this,_e||[]);
}
return this;
}};
var _f=function(_10){
this._index=-1;
this._animations=_10||[];
this._current=this._onAnimateCtx=this._onEndCtx=null;
this.duration=0;
_3.forEach(this._animations,function(a){
this.duration+=a.duration;
if(a.delay){
this.duration+=a.delay;
}
},this);
};
_1.extend(_f,{_onAnimate:function(){
this._fire("onAnimate",arguments);
},_onEnd:function(){
_4.disconnect(this._onAnimateCtx);
_4.disconnect(this._onEndCtx);
this._onAnimateCtx=this._onEndCtx=null;
if(this._index+1==this._animations.length){
this._fire("onEnd");
}else{
this._current=this._animations[++this._index];
this._onAnimateCtx=_4.connect(this._current,"onAnimate",this,"_onAnimate");
this._onEndCtx=_4.connect(this._current,"onEnd",this,"_onEnd");
this._current.play(0,true);
}
},play:function(_11,_12){
if(!this._current){
this._current=this._animations[this._index=0];
}
if(!_12&&this._current.status()=="playing"){
return this;
}
var _13=_4.connect(this._current,"beforeBegin",this,function(){
this._fire("beforeBegin");
}),_14=_4.connect(this._current,"onBegin",this,function(arg){
this._fire("onBegin",arguments);
}),_15=_4.connect(this._current,"onPlay",this,function(arg){
this._fire("onPlay",arguments);
_4.disconnect(_13);
_4.disconnect(_14);
_4.disconnect(_15);
});
if(this._onAnimateCtx){
_4.disconnect(this._onAnimateCtx);
}
this._onAnimateCtx=_4.connect(this._current,"onAnimate",this,"_onAnimate");
if(this._onEndCtx){
_4.disconnect(this._onEndCtx);
}
this._onEndCtx=_4.connect(this._current,"onEnd",this,"_onEnd");
this._current.play.apply(this._current,arguments);
return this;
},pause:function(){
if(this._current){
var e=_4.connect(this._current,"onPause",this,function(arg){
this._fire("onPause",arguments);
_4.disconnect(e);
});
this._current.pause();
}
return this;
},gotoPercent:function(_16,_17){
this.pause();
var _18=this.duration*_16;
this._current=null;
_3.some(this._animations,function(a){
if(a.duration<=_18){
this._current=a;
return true;
}
_18-=a.duration;
return false;
});
if(this._current){
this._current.gotoPercent(_18/this._current.duration,_17);
}
return this;
},stop:function(_19){
if(this._current){
if(_19){
for(;this._index+1<this._animations.length;++this._index){
this._animations[this._index].stop(true);
}
this._current=this._animations[this._index];
}
var e=_4.connect(this._current,"onStop",this,function(arg){
this._fire("onStop",arguments);
_4.disconnect(e);
});
this._current.stop();
}
return this;
},status:function(){
return this._current?this._current.status():"stopped";
},destroy:function(){
if(this._onAnimateCtx){
_4.disconnect(this._onAnimateCtx);
}
if(this._onEndCtx){
_4.disconnect(this._onEndCtx);
}
}});
_1.extend(_f,_c);
_b.chain=_2.fx.chain=function(_1a){
return new _f(_1a);
};
var _1b=function(_1c){
this._animations=_1c||[];
this._connects=[];
this._finished=0;
this.duration=0;
_3.forEach(_1c,function(a){
var _1d=a.duration;
if(a.delay){
_1d+=a.delay;
}
if(this.duration<_1d){
this.duration=_1d;
}
this._connects.push(_4.connect(a,"onEnd",this,"_onEnd"));
},this);
this._pseudoAnimation=new _5.Animation({curve:[0,1],duration:this.duration});
var _1e=this;
_3.forEach(["beforeBegin","onBegin","onPlay","onAnimate","onPause","onStop","onEnd"],function(evt){
_1e._connects.push(_4.connect(_1e._pseudoAnimation,evt,function(){
_1e._fire(evt,arguments);
}));
});
};
_1.extend(_1b,{_doAction:function(_1f,_20){
_3.forEach(this._animations,function(a){
a[_1f].apply(a,_20);
});
return this;
},_onEnd:function(){
if(++this._finished>this._animations.length){
this._fire("onEnd");
}
},_call:function(_21,_22){
var t=this._pseudoAnimation;
t[_21].apply(t,_22);
},play:function(_23,_24){
this._finished=0;
this._doAction("play",arguments);
this._call("play",arguments);
return this;
},pause:function(){
this._doAction("pause",arguments);
this._call("pause",arguments);
return this;
},gotoPercent:function(_25,_26){
var ms=this.duration*_25;
_3.forEach(this._animations,function(a){
a.gotoPercent(a.duration<ms?1:(ms/a.duration),_26);
});
this._call("gotoPercent",arguments);
return this;
},stop:function(_27){
this._doAction("stop",arguments);
this._call("stop",arguments);
return this;
},status:function(){
return this._pseudoAnimation.status();
},destroy:function(){
_3.forEach(this._connects,_4.disconnect);
}});
_1.extend(_1b,_c);
_b.combine=_2.fx.combine=function(_28){
return new _1b(_28);
};
_b.wipeIn=_2.fx.wipeIn=function(_29){
var _2a=_29.node=_6.byId(_29.node),s=_2a.style,o;
var _2b=_5.animateProperty(_1.mixin({properties:{height:{start:function(){
o=s.overflow;
s.overflow="hidden";
if(s.visibility=="hidden"||s.display=="none"){
s.height="1px";
s.display="";
s.visibility="";
return 1;
}else{
var _2c=_7.get(_2a,"height");
return Math.max(_2c,1);
}
},end:function(){
return _2a.scrollHeight;
}}}},_29));
var _2d=function(){
s.height="auto";
s.overflow=o;
};
_4.connect(_2b,"onStop",_2d);
_4.connect(_2b,"onEnd",_2d);
return _2b;
};
_b.wipeOut=_2.fx.wipeOut=function(_2e){
var _2f=_2e.node=_6.byId(_2e.node),s=_2f.style,o;
var _30=_5.animateProperty(_1.mixin({properties:{height:{end:1}}},_2e));
_4.connect(_30,"beforeBegin",function(){
o=s.overflow;
s.overflow="hidden";
s.display="";
});
var _31=function(){
s.overflow=o;
s.height="auto";
s.display="none";
};
_4.connect(_30,"onStop",_31);
_4.connect(_30,"onEnd",_31);
return _30;
};
_b.slideTo=_2.fx.slideTo=function(_32){
var _33=_32.node=_6.byId(_32.node),top=null,_34=null;
var _35=(function(n){
return function(){
var cs=_7.getComputedStyle(n);
var pos=cs.position;
top=(pos=="absolute"?n.offsetTop:parseInt(cs.top)||0);
_34=(pos=="absolute"?n.offsetLeft:parseInt(cs.left)||0);
if(pos!="absolute"&&pos!="relative"){
var ret=_8.position(n,true);
top=ret.y;
_34=ret.x;
n.style.position="absolute";
n.style.top=top+"px";
n.style.left=_34+"px";
}
};
})(_33);
_35();
var _36=_5.animateProperty(_1.mixin({properties:{top:_32.top||0,left:_32.left||0}},_32));
_4.connect(_36,"beforeBegin",_36,_35);
return _36;
};
_1.mixin(_2.fx,_b);
return _b;
});
