/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/gesture",["./_base/kernel","./_base/array","./_base/lang","./on","./touch","./has"],function(_1,_2,_3,on,_4,_5){
function _6(o){
for(var x in o){
return false;
}
return true;
};
_1.gesture={events:{},gestures:[],_gestureElements:[],register:function(_7){
if(!_7){
return;
}
if(!_5("touch")&&_7.touchOnly){
console.warn("Gestures:[",_7.defaultEvent,"] is only supported on touch devices!");
return;
}
if(_2.indexOf(this.gestures,_7)<0){
this.gestures.push(_7);
}
var _8=_7.defaultEvent;
this.events[_8]=_7;
_7.call=this.handle(_8);
_2.forEach(_7.subEvents,function(_9){
_7[_9]=this.handle(_8+"."+_9);
this.events[_8+"."+_9]=_7;
},this);
},unRegister:function(_a){
if(!_a){
return;
}
var _b=this;
function _c(_d,_e){
if(_b.events[_e]){
delete _b.events[_e];
}
_b._remove(_d,_e,null,true);
};
_2.forEach(this._gestureElements,function(_f){
_c(_f.target,_a.defaultEvent);
_2.forEach(_a.subEvents,function(_10){
_c(_f.target,_a.defaultEvent+"."+_10);
},this);
},this);
this._gestureElements=_2.filter(this._gestureElements,function(_11){
return !_6(_11.gestures);
});
var i=_2.indexOf(this.gestures,_a);
if(i>=0){
this.gestures.splice(i,1);
}
if(_a.destroy){
_a.destroy();
}
},handle:function(_12){
var _13=this;
return function(_14,_15){
var a=arguments;
if(a.length>2){
_14=a[1];
_15=a[2];
}
var _16=_14&&(_14.nodeType||_14.attachEvent||_14.addEventListener);
if(!_16||!_13.isGestureEvent(_12)){
return on(_14,_12,_15);
}else{
var _17={remove:function(){
_13._remove(_14,_12,_15);
}};
_13._add(_14,_12,_15);
return _17;
}
};
},isGestureEvent:function(e){
return !!this.events[e];
},isMouseEvent:function(_18){
return (/^mousedown$|^mousemove$|^mouseup$|^click$|^contextmenu$/).test(_18);
},_add:function(_19,_1a,_1b){
var _1c=this.getGestureElement(_19);
if(_1c===null){
_1c={target:_19,gestures:{},data:{},listening:false};
this._gestureElements.push(_1c);
}
var _1d=this.events[_1a];
if(_1d&&!_1c.data[_1d.defaultEvent]){
_1c.data[_1d.defaultEvent]={};
}
if(!_1c.gestures[_1a]){
_1c.gestures[_1a]={callbacks:[_1b],stopped:false};
}else{
_1c.gestures[_1a].callbacks.push(_1b);
}
if(!_1c.listening){
var _1e=_3.hitch(this,"_press",_1c);
var _1f=_3.hitch(this,"_move",_1c);
var _20=_3.hitch(this,"_release",_1c);
var _21=this.events[_1a].touchOnly;
if(_21){
_1c.press=on(_19,"touchstart",_1e);
_1c.move=on(_19,"touchmove",_1f);
_1c.release=on(_19,"touchend",_20);
}else{
_1c.press=_4.press(_19,_1e);
_1c.move=_4.move(_19,_1f);
_1c.release=_4.release(_19,_20);
}
if(_5("touch")){
var _22=_3.hitch(this,"_cancel",_1c);
_1c.cancel=on(_19,"touchcancel",_22);
}
_1c.listening=true;
}
},_remove:function(_23,_24,_25,_26){
var _27=this.getGestureElement(_23);
if(!_27){
return;
}
var _28=(_27.gestures[_24]||{}).callbacks;
if(!_28){
return;
}
var i;
if(_25){
i=_2.indexOf(_28,_25);
if(i>=0){
_28.splice(i,1);
}
}
if(_28.length===0||!_25){
delete _27.gestures[_24];
}
if(_6(_27.gestures)){
_2.forEach(["press","move","release","cancel"],function(_29){
if(_27[_29]&&_27[_29].remove){
_27[_29].remove();
}
});
if(_26){
return;
}
i=_2.indexOf(this._gestureElements,_27);
if(i>=0){
this._gestureElements.splice(i,1);
}
}
},getGestureElement:function(_2a){
var i;
for(i=0;i<this._gestureElements.length;i++){
var _2b=this._gestureElements[i];
if(_2b.target===_2a){
return _2b;
}
}
return null;
},_press:function(_2c,e){
this._forEach(_2c,"press",e);
},_move:function(_2d,e){
this._forEach(_2d,"move",e);
},_release:function(_2e,e){
this._forEach(_2e,"release",e);
},_cancel:function(_2f,e){
this._forEach(_2f,"cancel",e);
},_forEach:function(_30,_31,e){
e.preventDefault();
if(e.locking){
return;
}
var _32=[],x;
for(x in _30.gestures){
var _33=this.events[x];
if(_33[_31]&&_2.indexOf(_32,_33)<0){
e.locking=true;
_33[_31](_30.data[_33.defaultEvent],e);
_32.push(_33);
}
}
},fire:function(_34,_35,_36,_37){
var _38=((this.getGestureElement(_34)||{}).gestures||{})[_36];
if(!_38){
return;
}
if(!_37){
_37={};
}
_37.type=_36;
_37.target=_35;
_37.currentTarget=_34;
_37.preventDefault=function(){
};
_37.stopPropagation=function(){
_38.stopped=true;
};
this._fire(_34,_36,_37);
},_fire:function(_39,_3a,e){
var _3b=((this.getGestureElement(_39)||{}).gestures||{})[_3a];
if(!_3b){
return;
}
_2.forEach(_3b.callbacks,function(_3c){
_3c.call(_39,e);
});
if(!_3b.stopped){
var _3d=_39.parentNode;
if(_3d){
e.currentTarget=_3d;
this._fire(_3d,_3a,e);
}
}
},reset:function(){
var g;
while(g=this.gestures.pop()){
this.unRegister(g);
}
},destroy:function(){
this.reset();
}};
return _1.gesture;
});
