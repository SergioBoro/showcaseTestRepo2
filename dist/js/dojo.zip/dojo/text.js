/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/text",["./_base/kernel","require","./has","./_base/xhr"],function(_1,_2,_3,_4){
var _5;
if(1){
_5=function(_6,_7,_8){
_4("GET",{url:_6,sync:!!_7,load:_8});
};
}else{
if(_2.getText){
_5=_2.getText;
}else{
console.error("dojo/text plugin failed to load because loader does not support getText");
}
}
var _9={},_a=1?function(id,_b){
var _c=_b.toAbsMid(id+"/x");
return _c.substring(0,_c.length-2);
}:function(id,_d){
return _d.toUrl(id);
},_e=function(_f){
if(_f){
_f=_f.replace(/^\s*<\?xml(\s)+version=[\'\"](\d)*.(\d)*[\'\"](\s)*\?>/im,"");
var _10=_f.match(/<body[^>]*>\s*([\s\S]+)\s*<\/body>/im);
if(_10){
_f=_10[1];
}
}else{
_f="";
}
return _f;
},_11={},_12={},_13={load:function(id,_14,_15){
var _16=id.split("!"),_17=_16.length>1,_18=_a(_16[0],_14),url=_14.toUrl(_16[0]),_19=_11,_1a=function(_1b){
_15(_17?_e(_1b):_1b);
};
if(_18 in _9){
_19=_9[_18];
}else{
if(url in _14.cache){
_19=_14.cache[url];
}else{
if(url in _9){
_19=_9[url];
}
}
}
if(_19===_11){
if(_12[url]){
_12[url].push(_1a);
}else{
var _1c=_12[url]=[_1a];
_5(url,!_14.async,function(_1d){
_9[_18]=_9[url]=_1d;
for(var i=0;i<_1c.length;){
_1c[i++](_1d);
}
delete _12[url];
});
}
}else{
_1a(_19);
}
}};
_1.cache=function(_1e,url,_1f){
var key;
if(typeof _1e=="string"){
if(/\//.test(_1e)){
key=_1e;
_1f=url;
}else{
key=_2.toUrl(_1e.replace(/\./g,"/")+(url?("/"+url):""));
}
}else{
key=_1e+"";
_1f=url;
}
var val=(_1f!=undefined&&typeof _1f!="string")?_1f.value:_1f,_20=_1f&&_1f.sanitize;
if(typeof val=="string"){
_9[key]=val;
return _20?_e(val):val;
}else{
if(val===null){
delete _9[key];
return null;
}else{
if(!(key in _9)){
_5(key,true,function(_21){
_9[key]=_21;
});
}
return _20?_e(_9[key]):_9[key];
}
}
};
return _13;
});
