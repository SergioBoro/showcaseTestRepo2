/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/store/DataStore",["../main","./util/QueryResults"],function(_1){
_1.declare("dojo.store.DataStore",null,{target:"",constructor:function(_2){
_1.mixin(this,_2);
if(!"idProperty" in _2){
var _3;
try{
_3=this.store.getIdentityAttributes();
}
catch(e){
}
this.idProperty=(!_3||!idAttributes[0])||this.idProperty;
}
var _4=this.store.getFeatures();
if(!_4["dojo.data.api.Read"]){
this.get=null;
}
if(!_4["dojo.data.api.Identity"]){
this.getIdentity=null;
}
if(!_4["dojo.data.api.Write"]){
this.put=this.add=null;
}
},idProperty:"id",store:null,_objectConverter:function(_5){
var _6=this.store;
var _7=this.idProperty;
return function(_8){
var _9={};
var _a=_6.getAttributes(_8);
for(var i=0;i<_a.length;i++){
_9[_a[i]]=_6.getValue(_8,_a[i]);
}
if(!(_7 in _9)){
_9[_7]=_6.getIdentity(_8);
}
return _5(_9);
};
},get:function(id,_b){
var _c,_d;
var _e=new _1.Deferred();
this.store.fetchItemByIdentity({identity:id,onItem:this._objectConverter(function(_f){
_e.resolve(_c=_f);
}),onError:function(_10){
_e.reject(_d=_10);
}});
if(_c){
return _c;
}
if(_d){
throw _d;
}
return _e.promise;
},put:function(_11,_12){
var id=_12&&typeof _12.id!="undefined"||this.getIdentity(_11);
var _13=this.store;
var _14=this.idProperty;
if(typeof id=="undefined"){
_13.newItem(_11);
}else{
_13.fetchItemByIdentity({identity:id,onItem:function(_15){
if(_15){
for(var i in _11){
if(i!=_14&&_13.getValue(_15,i)!=_11[i]){
_13.setValue(_15,i,_11[i]);
}
}
}else{
_13.newItem(_11);
}
}});
}
},remove:function(id){
var _16=this.store;
this.store.fetchItemByIdentity({identity:id,onItem:function(_17){
_16.deleteItem(_17);
}});
},query:function(_18,_19){
var _1a;
var _1b=new _1.Deferred(function(){
_1a.abort&&_1a.abort();
});
_1b.total=new _1.Deferred();
var _1c=this._objectConverter(function(_1d){
return _1d;
});
_1a=this.store.fetch(_1.mixin({query:_18,onBegin:function(_1e){
_1b.total.resolve(_1e);
},onComplete:function(_1f){
_1b.resolve(_1.map(_1f,_1c));
},onError:function(_20){
_1b.reject(_20);
}},_19));
return _1.store.util.QueryResults(_1b);
},getIdentity:function(_21){
return _21[this.idProperty];
}});
return _1.store.DataStore;
});
