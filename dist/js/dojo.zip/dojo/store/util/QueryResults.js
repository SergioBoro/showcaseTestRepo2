/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/store/util/QueryResults",["../../_base/kernel","../../_base/lang","../../_base/Deferred"],function(_1,_2){
_2.getObject("store.util",true,_1);
_1.store.util.QueryResults=function(_3){
if(!_3){
return _3;
}
if(_3.then){
_3=_2.delegate(_3);
}
function _4(_5){
if(!_3[_5]){
_3[_5]=function(){
var _6=arguments;
return _1.when(_3,function(_7){
Array.prototype.unshift.call(_6,_7);
return _1.store.util.QueryResults(_1[_5].apply(_1,_6));
});
};
}
};
_4("forEach");
_4("filter");
_4("map");
if(!_3.total){
_3.total=_1.when(_3,function(_8){
return _8.length;
});
}
return _3;
};
return _1.store.util.QueryResults;
});
