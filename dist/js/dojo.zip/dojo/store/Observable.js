/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/store/Observable",["dojo/_base/kernel","dojo/_base/lang","dojo/_base/Deferred","dojo/_base/array"],function(_1,_2){
_2.getObject("store",true,_1);
return _1.store.Observable=function(_3){
var _4,_5=[],_6=0;
_3.notify=function(_7,_8){
_6++;
var _9=_5.slice();
for(var i=0,l=_9.length;i<l;i++){
_9[i](_7,_8);
}
};
var _a=_3.query;
_3.query=function(_b,_c){
_c=_c||{};
var _d=_a.apply(this,arguments);
if(_d&&_d.forEach){
var _e=_2.mixin({},_c);
delete _e.start;
delete _e.count;
var _f=_3.queryEngine&&_3.queryEngine(_b,_e);
var _10=_6;
var _11=[],_12;
_d.observe=function(_13,_14){
if(_11.push(_13)==1){
_5.push(_12=function(_15,_16){
_1.when(_d,function(_17){
var _18=_17.length!=_c.count;
var i,l;
if(++_10!=_6){
throw new Error("Query is out of date, you must observe() the query prior to any data modifications");
}
var _19,_1a=-1,_1b=-1;
if(_16!==_4){
for(i=0,l=_17.length;i<l;i++){
var _1c=_17[i];
if(_3.getIdentity(_1c)==_16){
_19=_1c;
_1a=i;
if(_f||!_15){
_17.splice(i,1);
}
break;
}
}
}
if(_f){
if(_15&&(_f.matches?_f.matches(_15):_f([_15]).length)){
var _1d=_1a>-1?_1a:_17.length;
_17.splice(_1d,0,_15);
_1b=_1.indexOf(_f(_17),_15);
_17.splice(_1d,1);
_17.splice(_1b,0,_15);
if((_c.start&&_1b==0)||(!_18&&_1b==_17.length-1)){
_1b=-1;
}
}
}else{
if(_15){
_1b=_1a>=0?_1a:(_3.defaultIndex||0);
}
}
if((_1a>-1||_1b>-1)&&(_14||!_f||(_1a!=_1b))){
var _1e=_11.slice();
for(i=0;_13=_1e[i];i++){
_13(_15||_19,_1a,_1b);
}
}
});
});
}
return {cancel:function(){
_11.splice(_1.indexOf(_11,_13),1);
if(!_11.length){
_5.splice(_1.indexOf(_5,_12),1);
}
}};
};
}
return _d;
};
var _1f;
function _20(_21,_22){
var _23=_3[_21];
if(_23){
_3[_21]=function(_24){
if(_1f){
return _23.apply(this,arguments);
}
_1f=true;
try{
return _1.when(_23.apply(this,arguments),function(_25){
_22((typeof _25=="object"&&_25)||_24);
return _25;
});
}
finally{
_1f=false;
}
};
}
};
_20("put",function(_26){
_3.notify(_26,_3.getIdentity(_26));
});
_20("add",function(_27){
_3.notify(_27);
});
_20("remove",function(id){
_3.notify(undefined,id);
});
return _3;
};
});
