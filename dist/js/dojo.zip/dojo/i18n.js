/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/i18n",["./_base/kernel","require","./has","./_base/array","./_base/lang","./_base/xhr"],function(_1,_2,_3,_4,_5){
var _6=_1.i18n={},_7=/(^.*(^|\/)nls)(\/|$)([^\/]*)\/?([^\/]*)/,_8=function(_9,_a,_b,_c){
for(var _d=[_b+_c],_e=_a.split("-"),_f="",i=0;i<_e.length;i++){
_f+=(_f?"-":"")+_e[i];
if(!_9||_9[_f]){
_d.push(_b+_f+"/"+_c);
}
}
return _d;
},_10={},_11=_1.getL10nName=function(_12,_13,_14){
_14=_14?_14.toLowerCase():_1.locale;
_12="dojo/i18n!"+_12.replace(/\./g,"/");
_13=_13.replace(/\./g,"/");
return (/root/i.test(_14))?(_12+"/nls/"+_13):(_12+"/nls/"+_14+"/"+_13);
},_15=function(_16,_17,_18,_19,_1a,_1b){
_16([_17],function(_1c){
var _1d=_10[_17+"/"]=_5.clone(_1c.root),_1e=_8(!_1c._v1x&&_1c,_1a,_18,_19);
_16(_1e,function(){
for(var i=1;i<_1e.length;i++){
_10[_1e[i]]=_1d=_5.mixin(_5.clone(_1d),arguments[i]);
}
var _1f=_17+"/"+_1a;
_10[_1f]=_1d;
_1b&&_1b(_5.delegate(_1d));
});
});
},_20=function(id,_21,_22){
var _23=_7.exec(id),_24=((_21.toAbsMid&&_21.toAbsMid(_23[1]))||_23[1])+"/",_25=_23[5]||_23[4],_26=_24+_25,_27=(_23[5]&&_23[4]),_28=_27||_1.locale,_29=_26+"/"+_28;
if(_27){
if(_10[_29]){
_22(_10[_29]);
}else{
_15(_21,_26,_24,_25,_28,_22);
}
return;
}
var _2a=_1.config.extraLocale||[];
_2a=_5.isArray(_2a)?_2a:[_2a];
_2a.push(_28);
_4.forEach(_2a,function(_2b){
_15(_21,_26,_24,_25,_2b,_2b==_28&&_22);
});
};
true||_3.add("dojo-v1x-i18n-Api",1);
if(1){
var _2c=new Function("bundle","var __preAmdResult, __amdResult; function define(bundle){__amdResult= bundle;} __preAmdResult= eval(bundle); return [__preAmdResult, __amdResult];"),_2d=function(url,_2e,_2f){
return _2e?(/nls\/[^\/]+\/[^\/]+$/.test(url)?_2e:{root:_2e,_v1x:1}):_2f;
},_30=function(_31,_32){
var _33=[];
_1.forEach(_31,function(mid){
var url=_2.toUrl(mid+".js");
if(_10[url]){
_33.push(_10[url]);
}else{
try{
var _34=_2(mid);
if(_34){
_33.push(_34);
return;
}
}
catch(e){
}
_1.xhrGet({url:url,sync:true,load:function(_35){
var _36=_2c(_35);
_33.push(_10[url]=_2d(url,_36[0],_36[1]));
},error:function(){
_33.push(_10[url]={});
}});
}
});
_32.apply(null,_33);
};
_30.toAbsMid=function(mid){
return _2.toAbsMid(mid);
};
_6.getLocalization=function(_37,_38,_39){
var _3a,_3b=_11(_37,_38,_39).substring(10),_3c=_2.isXdUrl(_2.toUrl(_3b+".js"));
_20(_3b,_3c?_2:_30,function(_3d){
_3a=_3d;
});
return _3a;
};
_6.normalizeLocale=function(_3e){
var _3f=_3e?_3e.toLowerCase():_1.locale;
if(_3f=="root"){
_3f="ROOT";
}
return _3f;
};
}
_6.load=_20;
_6.cache=function(mid,_40){
_10[mid]=_40;
};
return _6;
});
