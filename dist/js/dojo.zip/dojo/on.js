/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/on",["./aspect","./_base/kernel","./has"],function(_1,_2,_3){
"use strict";
var _4=_1.after;
if(1){
var _5=window.ScriptEngineMajorVersion;
_3.add("jscript",_5&&(_5()+ScriptEngineMinorVersion()/10));
_3.add("event-orientationchange",_3("touch")&&!_3("android"));
}
var on=function(_6,_7,_8,_9){
if(!_8){
return on(1&&("on"+_6) in window?window:on,_6,_7);
}
if(_6.on){
return _6.on(_7,_8);
}
return _a(_6,_7,_8,_9,this);
};
on.pausable=function(_b,_c,_d,_e){
var _f;
var _10=on(_b,_c,function(){
if(!_f){
return _d.apply(this,arguments);
}
},_e);
_10.pause=function(){
_f=true;
};
_10.resume=function(){
_f=false;
};
return _10;
};
on.once=function(_11,_12,_13,_14){
var _15=on(_11,_12,function(){
_15.remove();
return _13.apply(this,arguments);
});
return _15;
};
var _16=(on.Evented=function(){
}).prototype;
_16.on=function(_17,_18,_19){
return _a(this,_17,_18,_19,this);
};
var _1a=/^touch/;
function _a(_1b,_1c,_1d,_1e,_1f){
if(_1c.call){
return _1c.call(_1f,_1b,_1d);
}
if(_1c.indexOf(",")>-1){
var _20=_1c.split(/\s*,\s*/);
var _21=[];
var i=0;
var _22;
while(_22=_20[i++]){
_21.push(_a(_1b,_22,_1d,_1e,_1f));
}
_21.remove=function(){
for(var i=0;i<_21.length;i++){
_21[i].remove();
}
};
return _21;
}
var _23=_1c.match(/(.*):(.*)/);
if(_23){
_1c=_23[2];
_23=_23[1];
return on.selector(_23,_1c).call(_1f,_1b,_1d);
}
if(_3("touch")){
if(_1a.test(_1c)){
_1d=_4d(_1d);
}
if(!_3("event-orientationchange")&&(_1c=="orientationchange")){
_1c="resize";
_1b=window;
_1d=_4d(_1d);
}
}
if(_1b.addEventListener){
var _24=_1c in _37;
_1b.addEventListener(_24?_37[_1c]:_1c,_1d,_24);
return {remove:function(){
_1b.removeEventListener(_1c,_1d,_24);
}};
}
_1c="on"+_1c;
if(_25&&_1b.attachEvent){
return _25(_1b,_1c,_1d);
}
return _4(_1b,_1c,_1d,true);
};
on.selector=function(_26,_27){
return function(_28,_29){
var _2a=this;
return on(_28,_27,function(_2b){
var _2c=_2b.target;
_2a=_2a&&_2a.matches?_2a:_2.query;
while(!_2a.matches(_2c,_26,_28)){
if(_2c==_28||!(_2c=_2c.parentNode)){
return;
}
}
return _29.call(_2c,_2b);
});
};
};
function _2d(){
this.cancelable=false;
};
function _2e(){
this.bubbles=false;
};
var _2f=[].slice,_30=_16.emit=on.emit=function(_31,_32,_33){
var _34=_2f.call(arguments,2);
if(typeof _31=="string"){
_34.unshift(_33=_32);
_32=_31;
_31=this;
}
var _35="on"+_32;
if("parentNode" in _31){
var _36=_34[0]={};
for(var i in _33){
_36[i]=_33[i];
}
_36.preventDefault=_2d;
_36.stopPropagation=_2e;
_36.target=_31;
_36.type=_32;
_33=_36;
}
do{
_31[_35]&&_31[_35].apply(_31,_34);
}while(_33&&_33.bubbles&&(_31=_31.parentNode));
return _33&&_33.cancelable&&_33;
};
if(_3("dom-addeventlistener")){
var _37={focusin:"focus",focusout:"blur"};
if(_3("opera")){
_37.keydown="keypress";
}
on.emit=function(_38,_39,_3a){
if(_38.dispatchEvent&&document.createEvent){
var _3b=document.createEvent("HTMLEvents");
_3b.initEvent(_39,!!_3a.bubbles,!!_3a.cancelable);
for(var i in _3a){
var _3c=_3a[i];
if(!(i in _3b)){
_3b[i]=_3a[i];
}
}
return _38.dispatchEvent(_3b)&&_3b;
}
return _30.call(on,_38,_39,_3a);
};
}else{
on._fixEvent=function(evt,_3d){
if(!evt){
var w=_3d&&(_3d.ownerDocument||_3d.document||_3d).parentWindow||window;
evt=w.event;
}
if(!evt){
return (evt);
}
if(!evt.target){
evt.target=evt.srcElement;
evt.currentTarget=(_3d||evt.srcElement);
if(evt.type=="mouseover"){
evt.relatedTarget=evt.fromElement;
}
if(evt.type=="mouseout"){
evt.relatedTarget=evt.toElement;
}
if(!evt.stopPropagation){
evt.stopPropagation=_3e;
evt.preventDefault=_3f;
}
switch(evt.type){
case "keypress":
var c=("charCode" in evt?evt.charCode:evt.keyCode);
if(c==10){
c=0;
evt.keyCode=13;
}else{
if(c==13||c==27){
c=0;
}else{
if(c==3){
c=99;
}
}
}
evt.charCode=c;
_40(evt);
break;
}
}
return evt;
};
var _41=function(_42){
this.handle=_42;
};
_41.prototype.remove=function(){
delete _dojoIEListeners_[this.handle];
};
var _43=function(_44){
return function(evt){
evt=on._fixEvent(evt,this);
return _44.call(this,evt);
};
};
var _25=function(_45,_46,_47){
_47=_43(_47);
if(((_45.ownerDocument?_45.ownerDocument.parentWindow:_45.parentWindow||_45.window||window)!=top||_3("jscript")<5.8)&&!_3("config-_allow_leaks")){
if(typeof _dojoIEListeners_=="undefined"){
_dojoIEListeners_=[];
}
var _48=_45[_46];
if(!_48||!_48.listeners){
var _49=_48;
_45[_46]=_48=Function("event","var callee = arguments.callee; for(var i = 0; i<callee.listeners.length; i++){var listener = _dojoIEListeners_[callee.listeners[i]]; if(listener){listener.call(this,event);}}");
_48.listeners=[];
if(_49){
_48.listeners.push(_dojoIEListeners_.push(_49)-1);
}
}
var _4a;
_48.listeners.push(_4a=(_dojoIEListeners_.push(_47)-1));
return new _41(_4a);
}
return _4(_45,_46,_47,true);
};
var _40=function(evt){
evt.keyChar=evt.charCode?String.fromCharCode(evt.charCode):"";
evt.charOrCode=evt.keyChar||evt.keyCode;
};
var _3e=function(){
this.cancelBubble=true;
};
var _3f=on._preventDefault=function(){
this.bubbledKeyCode=this.keyCode;
if(this.ctrlKey){
try{
this.keyCode=0;
}
catch(e){
}
}
this.returnValue=false;
};
}
if(_3("touch")){
var _4b=function(){
};
var _4c=window.orientation;
var _4d=function(_4e){
return function(_4f){
var _50=_4f.corrected;
if(!_50){
var _51=_4f.type;
delete _4f.type;
if(_4f.type){
_4b.prototype=_4f;
var _50=new _4b;
_50.preventDefault=function(){
_4f.preventDefault();
};
_50.stopPropagation=function(){
_4f.stopPropagation();
};
}else{
_50=_4f;
_50.type=_51;
}
_4f.corrected=_50;
if(_51=="resize"){
if(_4c==window.orientation){
return null;
}
_4c=window.orientation;
_50.type="orientationchange";
return _4e.call(this,_50);
}
if(!("rotation" in _50)){
_50.rotation=0;
_50.scale=1;
}
var _52=_50.changedTouches[0];
for(var i in _52){
delete _50[i];
_50[i]=_52[i];
}
}
return _4e.call(this,_50);
};
};
}
return on;
});
