/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/dnd/Moveable",["../main","../touch","./Mover"],function(_1,_2){
_1.declare("dojo.dnd.Moveable",null,{handle:"",delay:0,skip:false,constructor:function(_3,_4){
this.node=_1.byId(_3);
if(!_4){
_4={};
}
this.handle=_4.handle?_1.byId(_4.handle):null;
if(!this.handle){
this.handle=this.node;
}
this.delay=_4.delay>0?_4.delay:0;
this.skip=_4.skip;
this.mover=_4.mover?_4.mover:_1.dnd.Mover;
this.events=[_1.connect(this.handle,_2.press,this,"onMouseDown"),_1.connect(this.handle,"ondragstart",this,"onSelectStart"),_1.connect(this.handle,"onselectstart",this,"onSelectStart")];
},markupFactory:function(_5,_6,_7){
return new _7(_6,_5);
},destroy:function(){
_1.forEach(this.events,_1.disconnect);
this.events=this.node=this.handle=null;
},onMouseDown:function(e){
if(this.skip&&_1.dnd.isFormElement(e)){
return;
}
if(this.delay){
this.events.push(_1.connect(this.handle,_2.move,this,"onMouseMove"),_1.connect(this.handle,_2.release,this,"onMouseUp"));
this._lastX=e.pageX;
this._lastY=e.pageY;
}else{
this.onDragDetected(e);
}
_1.stopEvent(e);
},onMouseMove:function(e){
if(Math.abs(e.pageX-this._lastX)>this.delay||Math.abs(e.pageY-this._lastY)>this.delay){
this.onMouseUp(e);
this.onDragDetected(e);
}
_1.stopEvent(e);
},onMouseUp:function(e){
for(var i=0;i<2;++i){
_1.disconnect(this.events.pop());
}
_1.stopEvent(e);
},onSelectStart:function(e){
if(!this.skip||!_1.dnd.isFormElement(e)){
_1.stopEvent(e);
}
},onDragDetected:function(e){
new this.mover(this.node,e,this);
},onMoveStart:function(_8){
_1.publish("/dnd/move/start",[_8]);
_1.addClass(_1.body(),"dojoMove");
_1.addClass(this.node,"dojoMoveItem");
},onMoveStop:function(_9){
_1.publish("/dnd/move/stop",[_9]);
_1.removeClass(_1.body(),"dojoMove");
_1.removeClass(this.node,"dojoMoveItem");
},onFirstMove:function(_a,e){
},onMove:function(_b,_c,e){
this.onMoving(_b,_c);
var s=_b.node.style;
s.left=_c.l+"px";
s.top=_c.t+"px";
this.onMoved(_b,_c);
},onMoving:function(_d,_e){
},onMoved:function(_f,_10){
}});
return _1.dnd.Moveable;
});
