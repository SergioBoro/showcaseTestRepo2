/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/dnd/Target", [ "./Source" ], function(Source){
	/*===== Source = dojo.dnd.Source =====*/
	return dojo.declare("dojo.dnd.Target", Source, {
		// summary: a Target object, which can be used as a DnD target

		constructor: function(node, params){
			// summary:
			//		a constructor of the Target --- see the `dojo.dnd.Source.constructor` for details
			this.isSource = false;
			dojo.removeClass(this.node, "dojoDndSource");
		}
	});
});
