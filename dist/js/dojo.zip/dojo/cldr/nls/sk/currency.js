//>>built
define(
//begin v1.x content
{
	"HKD_displayName": "Hong Kongský dolár",
	"CHF_displayName": "Švajčiarský frank",
	"CAD_displayName": "Kanadský dolár",
	"CNY_displayName": "Čínsky Yuan Renminbi",
	"AUD_displayName": "Austrálsky dolár",
	"JPY_displayName": "Japonský yen",
	"USD_displayName": "US dolár",
	"GBP_displayName": "Britská libra",
	"EUR_displayName": "Euro"
}
//end v1.x content
);