/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/ko/currency",{"HKD_displayName":"홍콩 달러","CHF_displayName":"스위스 프랑","CAD_displayName":"캐나다 달러","CNY_displayName":"중국 위안 인민폐","AUD_displayName":"호주 달러","JPY_displayName":"일본 엔화","USD_displayName":"미국 달러","GBP_displayName":"영국령 파운드 스털링","AUD_symbol":"AU$","EUR_displayName":"유로화"});
