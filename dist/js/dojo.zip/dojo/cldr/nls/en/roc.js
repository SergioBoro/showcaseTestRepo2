/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/en/roc",{"field-second":"Second","field-year-relative+-1":"Last year","field-week":"Week","field-month-relative+-1":"Last month","field-day-relative+-1":"Yesterday","field-year":"Year","field-week-relative+0":"This week","field-week-relative+1":"Next week","field-minute":"Minute","field-week-relative+-1":"Last week","field-day-relative+0":"Today","field-hour":"Hour","field-day-relative+1":"Tomorrow","field-day":"Day","field-month-relative+0":"This month","field-month-relative+1":"Next month","field-dayperiod":"AM/PM","field-month":"Month","field-era":"Era","field-year-relative+0":"This year","field-year-relative+1":"Next year","eraAbbr":["Before R.O.C.","Minguo"],"field-weekday":"Day of the Week","field-zone":"Time Zone"});
