/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define({ root:

//begin v1.x content
{
	"months-format-narrow": [
		"Tishri",
		"Heshvan",
		"Kislev",
		"Tevet",
		"Shevat",
		"Adar I",
		"Adar",
		"Nisan",
		"Iyar",
		"Sivan",
		"Tamuz",
		"Av",
		"Elul"
	],
	"quarters-standAlone-narrow": [
		"1",
		"2",
		"3",
		"4"
	],
	"dateFormatItem-yQQQ": "y QQQ",
	"months-standAlone-narrow-leap": "Adar II",
	"dateFormatItem-yMEd": "EEE, y-M-d",
	"dateFormatItem-MMMEd": "E MMM d",
	"eraNarrow": [
		"AM"
	],
	"dateTimeFormats-appendItem-Day-Of-Week": "{0} {1}",
	"dateFormat-long": "y MMMM d",
	"months-format-wide": [
		"Tishri",
		"Heshvan",
		"Kislev",
		"Tevet",
		"Shevat",
		"Adar I",
		"Adar",
		"Nisan",
		"Iyar",
		"Sivan",
		"Tamuz",
		"Av",
		"Elul"
	],
	"dateTimeFormat-medium": "{1} {0}",
	"dateFormatItem-EEEd": "d EEE",
	"dayPeriods-format-wide-pm": "PM",
	"dateFormat-full": "EEEE, y MMMM dd",
	"dateFormatItem-Md": "M-d",
	"dayPeriods-format-abbr-am": "AM",
	"dateTimeFormats-appendItem-Second": "{0} ({2}: {1})",
	"dateFormatItem-yM": "y-M",
	"months-standAlone-wide": [
		"Tishri",
		"Heshvan",
		"Kislev",
		"Tevet",
		"Shevat",
		"Adar I",
		"Adar",
		"Nisan",
		"Iyar",
		"Sivan",
		"Tamuz",
		"Av",
		"Elul"
	],
	"timeFormat-short": "HH:mm",
	"quarters-format-wide": [
		"Q1",
		"Q2",
		"Q3",
		"Q4"
	],
	"timeFormat-long": "HH:mm:ss z",
	"dateFormatItem-yMMM": "y MMM",
	"dateFormatItem-yQ": "y Q",
	"dateTimeFormats-appendItem-Era": "{0} {1}",
	"months-format-abbr-leap": "Adar II",
	"months-format-abbr": [
		"Tishri",
		"Heshvan",
		"Kislev",
		"Tevet",
		"Shevat",
		"Adar I",
		"Adar",
		"Nisan",
		"Iyar",
		"Sivan",
		"Tamuz",
		"Av",
		"Elul"
	],
	"timeFormat-full": "HH:mm:ss zzzz",
	"dateTimeFormats-appendItem-Week": "{0} ({2}: {1})",
	"dateFormatItem-H": "HH",
	"months-standAlone-abbr": [
		"Tishri",
		"Heshvan",
		"Kislev",
		"Tevet",
		"Shevat",
		"Adar I",
		"Adar",
		"Nisan",
		"Iyar",
		"Sivan",
		"Tamuz",
		"Av",
		"Elul"
	],
	"quarters-format-abbr": [
		"Q1",
		"Q2",
		"Q3",
		"Q4"
	],
	"quarters-standAlone-wide": [
		"Q1",
		"Q2",
		"Q3",
		"Q4"
	],
	"dateFormatItem-M": "L",
	"days-standAlone-wide": [
		"1",
		"2",
		"3",
		"4",
		"5",
		"6",
		"7"
	],
	"months-standAlone-wide-leap": "Adar II",
	"timeFormat-medium": "HH:mm:ss",
	"dateFormatItem-Hm": "HH:mm",
	"quarters-standAlone-abbr": [
		"Q1",
		"Q2",
		"Q3",
		"Q4"
	],
	"months-format-narrow-leap": "Adar II",
	"eraAbbr": [
		"AM"
	],
	"days-standAlone-abbr": [
		"1",
		"2",
		"3",
		"4",
		"5",
		"6",
		"7"
	],
	"dateFormatItem-d": "d",
	"dateFormatItem-ms": "mm:ss",
	"quarters-format-narrow": [
		"1",
		"2",
		"3",
		"4"
	],
	"dateFormatItem-h": "h a",
	"dateTimeFormat-long": "{1} {0}",
	"dayPeriods-format-narrow-am": "AM",
	"dateFormatItem-MMMd": "MMM d",
	"dateFormatItem-MEd": "E, M-d",
	"dateTimeFormat-full": "{1} {0}",
	"days-format-wide": [
		"1",
		"2",
		"3",
		"4",
		"5",
		"6",
		"7"
	],
	"months-standAlone-abbr-leap": "Adar II",
	"dateTimeFormats-appendItem-Day": "{0} ({2}: {1})",
	"dateFormatItem-y": "y",
	"months-standAlone-narrow": [
		"Tishri",
		"Heshvan",
		"Kislev",
		"Tevet",
		"Shevat",
		"Adar I",
		"Adar",
		"Nisan",
		"Iyar",
		"Sivan",
		"Tamuz",
		"Av",
		"Elul"
	],
	"dateFormatItem-hm": "h:mm a",
	"dateTimeFormats-appendItem-Year": "{0} {1}",
	"dateTimeFormats-appendItem-Hour": "{0} ({2}: {1})",
	"dayPeriods-format-abbr-pm": "PM",
	"days-format-abbr": [
		"1",
		"2",
		"3",
		"4",
		"5",
		"6",
		"7"
	],
	"eraNames": [
		"AM"
	],
	"days-format-narrow": [
		"1",
		"2",
		"3",
		"4",
		"5",
		"6",
		"7"
	],
	"days-standAlone-narrow": [
		"1",
		"2",
		"3",
		"4",
		"5",
		"6",
		"7"
	],
	"dateFormatItem-MMM": "LLL",
	"dateTimeFormats-appendItem-Quarter": "{0} ({2}: {1})",
	"dayPeriods-format-wide-am": "AM",
	"dateTimeFormats-appendItem-Month": "{0} ({2}: {1})",
	"dateTimeFormats-appendItem-Minute": "{0} ({2}: {1})",
	"dateFormat-short": "yyyy-MM-dd",
	"dateFormatItem-yMMMEd": "EEE, y MMM d",
	"dateTimeFormats-appendItem-Timezone": "{0} {1}",
	"dateFormat-medium": "y MMM d",
	"dayPeriods-format-narrow-pm": "PM",
	"dateTimeFormat-short": "{1} {0}",
	"dateFormatItem-Hms": "HH:mm:ss",
	"dateFormatItem-hms": "h:mm:ss a",
	"months-format-wide-leap": "Adar II"
}
//end v1.x content
,
	"ar": true,
	"el": true,
	"fi": true,
	"fr": true,
	"he": true,
	"hu": true,
	"nl": true,
	"ru": true,
	"sv": true,
	"th": true,
	"tr": true
});