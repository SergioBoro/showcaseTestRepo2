/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define(
//begin v1.x content
{
	"HKD_displayName": "Dolar hongkongský",
	"CHF_displayName": "Frank švýcarský",
	"CAD_displayName": "Dolar kanadský",
	"CNY_displayName": "Juan renminbi",
	"AUD_displayName": "Dolar australský",
	"JPY_displayName": "Jen",
	"USD_displayName": "Dolar americký",
	"GBP_displayName": "Libra šterlinků",
	"EUR_displayName": "Euro"
}
//end v1.x content
);