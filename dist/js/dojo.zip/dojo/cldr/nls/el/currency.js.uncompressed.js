define(
"dojo/cldr/nls/el/currency", //begin v1.x content
{
	"HKD_displayName": "Δολάριο Χονγκ Κονγκ",
	"CHF_displayName": "Φράγκο Ελβετίας",
	"JPY_symbol": "JP¥",
	"CAD_displayName": "Δολάριο Καναδά",
	"HKD_symbol": "HK$",
	"CNY_displayName": "Γουάν Κίνας",
	"USD_symbol": "$",
	"AUD_displayName": "Δολάριο Αυστραλίας",
	"JPY_displayName": "Γιεν Ιαπωνίας",
	"CAD_symbol": "CA$",
	"USD_displayName": "Δολάριο ΗΠΑ",
	"EUR_symbol": "€",
	"CNY_symbol": "CN¥",
	"GBP_displayName": "Λίρα Στερλίνα Βρετανίας",
	"GBP_symbol": "£",
	"AUD_symbol": "A$",
	"EUR_displayName": "Ευρώ"
}
//end v1.x content
);