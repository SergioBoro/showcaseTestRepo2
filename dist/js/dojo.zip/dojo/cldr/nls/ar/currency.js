/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/ar/currency",{"HKD_displayName":"دولار هونج كونج","CHF_displayName":"فرنك سويسري","JPY_symbol":"JP¥","CAD_displayName":"دولار كندي","HKD_symbol":"HK$","CNY_displayName":"يوان صيني","USD_symbol":"US$","AUD_displayName":"دولار أسترالي","JPY_displayName":"ين ياباني","CAD_symbol":"CA$","USD_displayName":"دولار أمريكي","EUR_symbol":"€","CNY_symbol":"ي.ص","GBP_displayName":"جنيه إسترليني","GBP_symbol":"£","AUD_symbol":"AU$","EUR_displayName":"يورو"});
