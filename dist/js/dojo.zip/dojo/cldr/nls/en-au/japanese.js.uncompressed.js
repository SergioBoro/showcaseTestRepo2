define(
"dojo/cldr/nls/en-au/japanese", //begin v1.x content
{
	"dateFormat-short": "d/MM/yy GGGGG",
	"dateFormat-medium": "dd/MM/y G",
	"dateFormat-long": "d MMMM y G",
	"dateFormat-full": "EEEE, d MMMM y G"
}
//end v1.x content
);