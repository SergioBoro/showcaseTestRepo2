/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define(
//begin v1.x content
{
	"HKD_displayName": "Dólar de Hong Kong",
	"CHF_displayName": "Franco suíço",
	"CAD_displayName": "Dólar canadense",
	"CNY_displayName": "Yuan Renminbi chinês",
	"AUD_displayName": "Dólar australiano",
	"JPY_displayName": "Iene japonês",
	"USD_displayName": "Dólar norte-americano",
	"GBP_displayName": "Libra esterlina britânica",
	"EUR_displayName": "Euro"
}
//end v1.x content
);