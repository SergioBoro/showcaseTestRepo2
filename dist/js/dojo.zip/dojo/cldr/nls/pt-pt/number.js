/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/pt-pt/number",{"group":" ","decimalFormat-long":"000 biliões","currencyFormat":"#,##0.00 ¤","decimalFormat-short":"000 Bi","decimal":","});
