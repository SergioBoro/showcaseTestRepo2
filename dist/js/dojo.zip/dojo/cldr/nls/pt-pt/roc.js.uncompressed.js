define(
"dojo/cldr/nls/pt-pt/roc", //begin v1.x content
{
	"field-zone": "Fuso horário",
	"dateFormat-short": "d/M/y G"
}
//end v1.x content
);