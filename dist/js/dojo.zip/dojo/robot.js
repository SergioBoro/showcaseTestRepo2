/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/robot",["dojo","doh/_browserRunner","doh/robot","dojo/window"],function(_1,_2){
_1.experimental("dojo.robot");
_1.mixin(_2.robot,{_resolveNode:function(n){
if(typeof n=="function"){
n=n();
}
return n?_1.byId(n):null;
},_scrollIntoView:function(n){
var dr=_2.robot,p=null;
_1.forEach(dr._getWindowChain(n),function(w){
_1.withGlobal(w,function(){
var p2=_1.position(n,false),b=_1._getPadBorderExtents(n),_3=null;
if(!p){
p=p2;
}else{
_3=p;
p={x:p.x+p2.x+b.l,y:p.y+p2.y+b.t,w:p.w,h:p.h};
}
_1.window.scrollIntoView(n,p);
p2=_1.position(n,false);
if(!_3){
p=p2;
}else{
p={x:_3.x+p2.x+b.l,y:_3.y+p2.y+b.t,w:p.w,h:p.h};
}
n=w.frameElement;
});
});
},_position:function(n){
var p=null,M=Math.max,m=Math.min;
_1.forEach(_2.robot._getWindowChain(n),function(w){
_1.withGlobal(w,function(){
var p2=_1.position(n,false),b=_1._getPadBorderExtents(n);
if(!p){
p=p2;
}else{
var _4;
_1.withGlobal(n.contentWindow,function(){
_4=_1.window.getBox();
});
p2.r=p2.x+_4.w;
p2.b=p2.y+_4.h;
p={x:M(p.x+p2.x,p2.x)+b.l,y:M(p.y+p2.y,p2.y)+b.t,r:m(p.x+p2.x+p.w,p2.r)+b.l,b:m(p.y+p2.y+p.h,p2.b)+b.t};
p.w=p.r-p.x;
p.h=p.b-p.y;
}
n=w.frameElement;
});
});
return p;
},_getWindowChain:function(n){
var cW=_1.window.get(n.ownerDocument);
var _5=[cW];
var f=cW.frameElement;
return (cW==_1.global||f==null)?_5:_5.concat(_2.robot._getWindowChain(f));
},scrollIntoView:function(_6,_7){
_2.robot.sequence(function(){
_2.robot._scrollIntoView(_2.robot._resolveNode(_6));
},_7);
},mouseMoveAt:function(_8,_9,_a,_b,_c){
_2.robot._assertRobot();
_a=_a||100;
this.sequence(function(){
_8=_2.robot._resolveNode(_8);
_2.robot._scrollIntoView(_8);
var _d=_2.robot._position(_8);
if(_c===undefined){
_b=_d.w/2;
_c=_d.h/2;
}
var x=_d.x+_b;
var y=_d.y+_c;
_2.robot._mouseMove(x,y,false,_a);
},_9,_a);
}});
return _2.robot;
});
