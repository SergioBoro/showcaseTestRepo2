/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/gesture/tap",["dojo","../gesture"],function(_1,_2){
var _3=_1.declare(null,{holdThreshold:500,doubleTapTimeout:250,tapRadius:10,defaultEvent:"tap",subEvents:["hold","doubletap"],constructor:function(_4){
_1.mixin(this,_4);
},press:function(_5,e){
if(e.touches&&e.touches.length>=2){
delete _5.tapContext;
return;
}
var _6=e.target,_7=e.currentTarget;
this._initTap(_5,e);
clearTimeout(_5.tapTimeOut);
_5.tapTimeOut=setTimeout(_1.hitch(this,function(){
if(this._isTap(_5,e)){
_2.fire(_7,_6,"tap.hold");
}
clearTimeout(_5.tapTimeOut);
delete _5.tapContext;
}),this.holdThreshold);
},release:function(_8,e){
if(!_8.tapContext){
clearTimeout(_8.tapTimeOut);
return;
}
switch(_8.tapContext.c){
case 1:
_2.fire(e.currentTarget,e.target,"tap");
break;
case 2:
if(this._isTap(_8,e)){
_2.fire(e.currentTarget,e.target,"tap.doubletap");
}
break;
}
clearTimeout(_8.tapTimeOut);
},_initTap:function(_9,e){
if(!_9.tapContext){
_9.tapContext={x:0,y:0,t:0,c:0};
}
var ct=new Date().getTime();
if(ct-_9.tapContext.t<=this.doubleTapTimeout){
_9.tapContext.c++;
}else{
_9.tapContext.c=1;
_9.tapContext.x=e.screenX;
_9.tapContext.y=e.screenY;
}
_9.tapContext.t=ct;
},_isTap:function(_a,e){
var dx=Math.abs(_a.tapContext.x-e.screenX);
var dy=Math.abs(_a.tapContext.y-e.screenY);
return dx<=this.tapRadius&&dy<=this.tapRadius;
},destroy:function(){
}});
_1.gesture.tap=new _3();
_1.gesture.tap.Tap=_3;
_2.register(_1.gesture.tap);
return _1.gesture.tap;
});
