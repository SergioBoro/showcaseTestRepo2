/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/data/api/Request",["../.."],function(_1){
_1.declare("dojo.data.api.Request",null,{abort:function(){
throw new Error("Unimplemented API: dojo.data.api.Request.abort");
}});
return _1.data.api.Request;
});
