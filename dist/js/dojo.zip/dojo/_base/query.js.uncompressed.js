//>>built
define("dojo/_base/query", ["./kernel", "../query", "./NodeList"], function(dojo){
	return dojo.query;
});
