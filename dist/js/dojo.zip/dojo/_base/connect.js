/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/_base/connect",["./kernel","../on","../aspect","./event","../mouse","./sniff","./lang","../keys"],function(_1,on,_2,_3,_4,_5,_6){
_5.add("events-keypress-typed",function(){
var _7={charCode:0};
try{
_7=document.createEvent("KeyboardEvent");
(_7.initKeyboardEvent||_7.initKeyEvent).call(_7,"keypress",true,true,null,false,false,false,false,9,3);
}
catch(e){
}
return _7.charCode==0&&!_5("opera");
});
function _8(_9,_a,_b,_c,_d){
if(typeof _a=="string"&&_a.substring(0,2)=="on"){
_a=_a.substring(2);
}else{
if(!_9||!(_9.addEventListener||_9.attachEvent)){
return _2.after(_9||_1.global,_a,_6.hitch(_b,_c),true);
}
}
if(!_9){
_9=_1.global;
}
if(!_d){
switch(_a){
case "keypress":
_a=_e;
break;
case "mouseenter":
_a=_4.enter;
break;
case "mouseleave":
_a=_4.leave;
break;
}
}
return on(_9,_a,_6.hitch(_b,_c),_d);
};
var _f={106:42,111:47,186:59,187:43,188:44,189:45,190:46,191:47,192:96,219:91,220:92,221:93,222:39,229:113};
var _10=_5("mac")?"metaKey":"ctrlKey";
var _11=function(evt,_12){
var _13=_6.mixin({},evt,_12);
_14(_13);
_13.preventDefault=function(){
evt.preventDefault();
};
_13.stopPropagation=function(){
evt.stopPropagation();
};
return _13;
};
function _14(evt){
evt.keyChar=evt.charCode?String.fromCharCode(evt.charCode):"";
evt.charOrCode=evt.keyChar||evt.keyCode;
};
var _e;
if(_5("events-keypress-typed")){
var _15=function(e,_16){
try{
return (e.keyCode=_16);
}
catch(e){
return 0;
}
};
_e=function(_17,_18){
var _19=on(_17,"keydown",function(evt){
var k=evt.keyCode;
var _1a=(k!=13||(_5("ie")>=9&&!_5("quirks")))&&k!=32&&(k!=27||!_5("ie"))&&(k<48||k>90)&&(k<96||k>111)&&(k<186||k>192)&&(k<219||k>222)&&k!=229;
if(_1a||evt.ctrlKey){
var c=_1a?0:k;
if(evt.ctrlKey){
if(k==3||k==13){
return _18.call(evt.currentTarget,evt);
}else{
if(c>95&&c<106){
c-=48;
}else{
if((!evt.shiftKey)&&(c>=65&&c<=90)){
c+=32;
}else{
c=_f[c]||c;
}
}
}
}
var _1b=_11(evt,{type:"keypress",faux:true,charCode:c});
_18.call(evt.currentTarget,_1b);
if(_5("ie")){
_15(evt,_1b.keyCode);
}
}
});
var _1c=on(_17,"keypress",function(evt){
var c=evt.charCode;
c=c>=32?c:0;
evt=_11(evt,{charCode:c,faux:true});
return _18.call(this,evt);
});
return {remove:function(){
_19.remove();
_1c.remove();
}};
};
}else{
if(_5("opera")){
_e=function(_1d,_1e){
return on(_1d,"keypress",function(evt){
var c=evt.which;
if(c==3){
c=99;
}
c=c<32&&!evt.shiftKey?0:c;
if(evt.ctrlKey&&!evt.shiftKey&&c>=65&&c<=90){
c+=32;
}
return _1e.call(this,_11(evt,{charCode:c}));
});
};
}else{
_e=function(_1f,_20){
return on(_1f,"keypress",function(evt){
_14(evt);
return _20.call(this,evt);
});
};
}
}
var _21={_keypress:_e,connect:function(obj,_22,_23,_24,_25){
var a=arguments,_26=[],i=0;
_26.push(typeof a[0]=="string"?null:a[i++],a[i++]);
var a1=a[i+1];
_26.push(typeof a1=="string"||typeof a1=="function"?a[i++]:null,a[i++]);
for(var l=a.length;i<l;i++){
_26.push(a[i]);
}
return _8.apply(this,_26);
},disconnect:function(_27){
if(_27){
_27.remove();
}
},subscribe:function(_28,_29,_2a){
return on(_28,_6.hitch(_29,_2a));
},publish:function(_2b,_2c){
_2b="on"+_2b;
on[_2b]&&on[_2b].apply(this,_2c||[]);
},connectPublisher:function(_2d,obj,_2e){
var pf=function(){
_21.publish(_2d,arguments);
};
return _2e?_21.connect(obj,_2e,pf):_21.connect(obj,pf);
},isCopyKey:function(e){
return e[_10];
}};
_21.unsubscribe=_21.disconnect;
1&&_6.mixin(_1,_21);
return _21;
});
