/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/_base/fx",["./kernel","./lang","./Color","./connect","./sniff","../dom","../dom-style"],function(_1,_2,_3,_4,_5,_6,_7){
var _8=_2.mixin;
_1._Line=function(_9,_a){
this.start=_9;
this.end=_a;
};
_1._Line.prototype.getValue=function(n){
return ((this.end-this.start)*n)+this.start;
};
_1.Animation=function(_b){
_8(this,_b);
if(_2.isArray(this.curve)){
this.curve=new _1._Line(this.curve[0],this.curve[1]);
}
};
_1._Animation=_1.Animation;
_2.extend(_1.Animation,{duration:350,repeat:0,rate:20,_percent:0,_startRepeatCount:0,_getStep:function(){
var _c=this._percent,_d=this.easing;
return _d?_d(_c):_c;
},_fire:function(_e,_f){
var a=_f||[];
if(this[_e]){
if(_1.config.debugAtAllCosts){
this[_e].apply(this,a);
}else{
try{
this[_e].apply(this,a);
}
catch(e){
console.error("exception in animation handler for:",_e);
console.error(e);
}
}
}
return this;
},play:function(_10,_11){
var _12=this;
if(_12._delayTimer){
_12._clearTimer();
}
if(_11){
_12._stopTimer();
_12._active=_12._paused=false;
_12._percent=0;
}else{
if(_12._active&&!_12._paused){
return _12;
}
}
_12._fire("beforeBegin",[_12.node]);
var de=_10||_12.delay,_13=_2.hitch(_12,"_play",_11);
if(de>0){
_12._delayTimer=setTimeout(_13,de);
return _12;
}
_13();
return _12;
},_play:function(_14){
var _15=this;
if(_15._delayTimer){
_15._clearTimer();
}
_15._startTime=new Date().valueOf();
if(_15._paused){
_15._startTime-=_15.duration*_15._percent;
}
_15._active=true;
_15._paused=false;
var _16=_15.curve.getValue(_15._getStep());
if(!_15._percent){
if(!_15._startRepeatCount){
_15._startRepeatCount=_15.repeat;
}
_15._fire("onBegin",[_16]);
}
_15._fire("onPlay",[_16]);
_15._cycle();
return _15;
},pause:function(){
var _17=this;
if(_17._delayTimer){
_17._clearTimer();
}
_17._stopTimer();
if(!_17._active){
return _17;
}
_17._paused=true;
_17._fire("onPause",[_17.curve.getValue(_17._getStep())]);
return _17;
},gotoPercent:function(_18,_19){
var _1a=this;
_1a._stopTimer();
_1a._active=_1a._paused=true;
_1a._percent=_18;
if(_19){
_1a.play();
}
return _1a;
},stop:function(_1b){
var _1c=this;
if(_1c._delayTimer){
_1c._clearTimer();
}
if(!_1c._timer){
return _1c;
}
_1c._stopTimer();
if(_1b){
_1c._percent=1;
}
_1c._fire("onStop",[_1c.curve.getValue(_1c._getStep())]);
_1c._active=_1c._paused=false;
return _1c;
},status:function(){
if(this._active){
return this._paused?"paused":"playing";
}
return "stopped";
},_cycle:function(){
var _1d=this;
if(_1d._active){
var _1e=new Date().valueOf();
var _1f=(_1e-_1d._startTime)/(_1d.duration);
if(_1f>=1){
_1f=1;
}
_1d._percent=_1f;
if(_1d.easing){
_1f=_1d.easing(_1f);
}
_1d._fire("onAnimate",[_1d.curve.getValue(_1f)]);
if(_1d._percent<1){
_1d._startTimer();
}else{
_1d._active=false;
if(_1d.repeat>0){
_1d.repeat--;
_1d.play(null,true);
}else{
if(_1d.repeat==-1){
_1d.play(null,true);
}else{
if(_1d._startRepeatCount){
_1d.repeat=_1d._startRepeatCount;
_1d._startRepeatCount=0;
}
}
}
_1d._percent=0;
_1d._fire("onEnd",[_1d.node]);
!_1d.repeat&&_1d._stopTimer();
}
}
return _1d;
},_clearTimer:function(){
clearTimeout(this._delayTimer);
delete this._delayTimer;
}});
var ctr=0,_20=null,_21={run:function(){
}};
_2.extend(_1.Animation,{_startTimer:function(){
if(!this._timer){
this._timer=_4.connect(_21,"run",this,"_cycle");
ctr++;
}
if(!_20){
_20=setInterval(_2.hitch(_21,"run"),this.rate);
}
},_stopTimer:function(){
if(this._timer){
_4.disconnect(this._timer);
this._timer=null;
ctr--;
}
if(ctr<=0){
clearInterval(_20);
_20=null;
ctr=0;
}
}});
var _22=_5("ie")?function(_23){
var ns=_23.style;
if(!ns.width.length&&_7.get(_23,"width")=="auto"){
ns.width="auto";
}
}:function(){
};
_1._fade=function(_24){
_24.node=_6.byId(_24.node);
var _25=_8({properties:{}},_24),_26=(_25.properties.opacity={});
_26.start=!("start" in _25)?function(){
return +_7.get(_25.node,"opacity")||0;
}:_25.start;
_26.end=_25.end;
var _27=_1.animateProperty(_25);
_4.connect(_27,"beforeBegin",_2.partial(_22,_25.node));
return _27;
};
_1.fadeIn=function(_28){
return _1._fade(_8({end:1},_28));
};
_1.fadeOut=function(_29){
return _1._fade(_8({end:0},_29));
};
_1._defaultEasing=function(n){
return 0.5+((Math.sin((n+1.5)*Math.PI))/2);
};
var _2a=function(_2b){
this._properties=_2b;
for(var p in _2b){
var _2c=_2b[p];
if(_2c.start instanceof _3){
_2c.tempColor=new _3();
}
}
};
_2a.prototype.getValue=function(r){
var ret={};
for(var p in this._properties){
var _2d=this._properties[p],_2e=_2d.start;
if(_2e instanceof _3){
ret[p]=_3.blendColors(_2e,_2d.end,r,_2d.tempColor).toCss();
}else{
if(!_2.isArray(_2e)){
ret[p]=((_2d.end-_2e)*r)+_2e+(p!="opacity"?_2d.units||"px":0);
}
}
}
return ret;
};
_1.animateProperty=function(_2f){
var n=_2f.node=_6.byId(_2f.node);
if(!_2f.easing){
_2f.easing=_1._defaultEasing;
}
var _30=new _1.Animation(_2f);
_4.connect(_30,"beforeBegin",_30,function(){
var pm={};
for(var p in this.properties){
if(p=="width"||p=="height"){
this.node.display="block";
}
var _31=this.properties[p];
if(_2.isFunction(_31)){
_31=_31(n);
}
_31=pm[p]=_8({},(_2.isObject(_31)?_31:{end:_31}));
if(_2.isFunction(_31.start)){
_31.start=_31.start(n);
}
if(_2.isFunction(_31.end)){
_31.end=_31.end(n);
}
var _32=(p.toLowerCase().indexOf("color")>=0);
function _33(_34,p){
var v={height:_34.offsetHeight,width:_34.offsetWidth}[p];
if(v!==undefined){
return v;
}
v=_7.get(_34,p);
return (p=="opacity")?+v:(_32?v:parseFloat(v));
};
if(!("end" in _31)){
_31.end=_33(n,p);
}else{
if(!("start" in _31)){
_31.start=_33(n,p);
}
}
if(_32){
_31.start=new _3(_31.start);
_31.end=new _3(_31.end);
}else{
_31.start=(p=="opacity")?+_31.start:parseFloat(_31.start);
}
}
this.curve=new _2a(pm);
});
_4.connect(_30,"onAnimate",_2.hitch(_1,"style",_30.node));
return _30;
};
_1.anim=function(_35,_36,_37,_38,_39,_3a){
return _1.animateProperty({node:_35,duration:_37||_1.Animation.prototype.duration,properties:_36,easing:_38,onEnd:_39}).play(_3a||0);
};
return {_Line:_1._Line,Animation:_1.Animation,_fade:_1._fade,fadeIn:_1.fadeIn,fadeOut:_1.fadeOut,_defaultEasing:_1._defaultEasing,animateProperty:_1.animateProperty,anim:_1.anim};
});
