/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/_base/array",["./kernel","./lang"],function(_1,_2){
var _3={},u,_4;
function _5(){
_3={};
};
function _6(fn){
return _3[fn]=new Function("item","index","array",fn);
};
function _7(_8){
var _9=!_8;
return function(a,fn,o){
var i=0,l=a&&a.length||0,_a;
if(l&&typeof a=="string"){
a=a.split("");
}
if(typeof fn=="string"){
fn=_3[fn]||_6(fn);
}
if(o){
for(;i<l;++i){
_a=!fn.call(o,a[i],i,a);
if(_8^_a){
return !_a;
}
}
}else{
for(;i<l;++i){
_a=!fn(a[i],i,a);
if(_8^_a){
return !_a;
}
}
}
return _9;
};
};
function _b(up){
var _c=1,_d=0,_e=0;
if(!up){
_c=_d=_e=-1;
}
return function(a,x,_f,_10){
if(_10&&_c>0){
return _4.lastIndexOf(a,x,_f);
}
var l=a&&a.length||0,end=up?l+_e:_d,i;
if(_f===u){
i=up?_d:l+_e;
}else{
if(_f<0){
i=l+_f;
if(i<0){
i=_d;
}
}else{
i=_f>=l?l+_e:_f;
}
}
if(l&&typeof a=="string"){
a=a.split("");
}
for(;i!=end;i+=_c){
if(a[i]==x){
return i;
}
}
return -1;
};
};
function _11(a,fn,o){
var i=0,l=a&&a.length||0;
if(l&&typeof a=="string"){
a=a.split("");
}
if(typeof fn=="string"){
fn=_3[fn]||_6(fn);
}
if(o){
for(;i<l;++i){
fn.call(o,a[i],i,a);
}
}else{
for(;i<l;++i){
fn(a[i],i,a);
}
}
};
function map(a,fn,o,Ctr){
var i=0,l=a&&a.length||0,out=new (Ctr||Array)(l);
if(l&&typeof a=="string"){
a=a.split("");
}
if(typeof fn=="string"){
fn=_3[fn]||_6(fn);
}
if(o){
for(;i<l;++i){
out[i]=fn.call(o,a[i],i,a);
}
}else{
for(;i<l;++i){
out[i]=fn(a[i],i,a);
}
}
return out;
};
function _12(a,fn,o){
var i=0,l=a&&a.length||0,out=[],_13;
if(l&&typeof a=="string"){
a=a.split("");
}
if(typeof fn=="string"){
fn=_3[fn]||_6(fn);
}
if(o){
for(;i<l;++i){
_13=a[i];
if(fn.call(o,_13,i,a)){
out.push(_13);
}
}
}else{
for(;i<l;++i){
_13=a[i];
if(fn(_13,i,a)){
out.push(_13);
}
}
}
return out;
};
_4={every:_7(false),some:_7(true),indexOf:_b(true),lastIndexOf:_b(false),forEach:_11,map:map,filter:_12,clearCache:_5};
_2.mixin(_1,_4);
return _4;
});
