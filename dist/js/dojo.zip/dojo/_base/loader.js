/*
	Copyright (c) 2004-2011, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/_base/loader",["./kernel","../has","require","module","./json","./lang","./array","./xhr"],function(_1,_2,_3,_4,_5,_6,_7,_8){
if(!1){
console.error("cannot load the Dojo v1.x loader with a foreign loader");
return 0;
}
var _9=function(){
return 0;
};
if(1){
var _a=location.protocol,_b=location.host,_c=!_b;
_9=function(_d){
if(_c||/^\./.test(_d)){
return false;
}
if(/^\/\//.test(_d)){
return true;
}
var _e=_d.match(/^([^\/\:]+\:)\/\/([^\/]+)/);
return _e&&(_e[1]!=_a||_e[2]!=_b);
};
}
var _f=function(id){
return {src:_4.id,id:id};
},_10=function(_11){
return _11.replace(/\./g,"/");
},_12=/\/\/>>built/,_13={},_14={},_15=function(mid,_16,_17){
var _18=_16.module,_19=1,_1a=function(){
if(--_19==0){
_17(1);
}
};
var _1b="dojo/require!"+_16.module.mid+"!"+mid,_1c;
_7.some(_16.module.deps,function(_1d){
if(_1b==_1d.mid){
_1c=_1d.dojoRequireMids=[];
return 1;
}
return 0;
});
_7.forEach(mid.split(","),function(mid){
_19++;
var _1e=_1f(mid,_16.module);
mid=_1e.mid;
_1c&&_1c.push(mid);
(_13[mid]||(_13[mid]=[])).push(_1a);
_20(_1e);
});
_21();
_1a();
},_21=function(){
var _22=[],_23=[],_24=function(mid){
if(_22[mid]!==undefined){
return _22[mid];
}
var _25=_5e[mid];
if(_25.executed){
return (_22[mid]=1);
}
if(_25.injected!==_59){
return (_22[mid]=0);
}
if(_23[mid]){
return 1;
}
_23[mid]=1;
for(var dep,i=0,_26=_25.deps||[],end=_26.length;i<end;){
dep=_26[i++];
if((dep.dojoRequireMids&&!_7.every(dep.dojoRequireMids,_24))||!_24(dep.mid)){
return _22[_25.mid]=0;
}
}
return _22[mid]=1;
},p,_27=0;
for(p in _13){
_24(p);
}
for(p in _22){
if(_22[p]&&_13[p]){
_7.forEach(_13[p],function(_28){
_28();
});
delete _13[p];
_27=1;
}
}
return _27?(_21()||1):0;
},_29=function(mid,_2a,_2b){
_2a([mid],function(_2c){
_2a(_2c.names,function(){
for(var _2d="",_2e=[],i=0;i<arguments.length;i++){
_2d+="var "+_2c.names[i]+"= arguments["+i+"]; ";
_2e.push(arguments[i]);
}
eval(_2d);
var _2f=_2a.module,_30=[],_31={},_32=[],p,_33={provide:function(_34){
_34=_10(_34);
var _35=_1f(_34,_2f);
if(_35!==_2f){
_61(_35);
}
},require:function(_36,_37){
_36=_10(_36);
_37&&(_1f(_36,_2f).result=_5a);
_32.push(_36);
},requireLocalization:function(_38,_39,_3a){
_30.length||(_30=["dojo/i18n"]);
_3a=(_3a||_1.locale).toLowerCase();
_38=_10(_38)+"/nls/"+(/root/i.test(_3a)?"":_3a+"/")+_10(_39);
if(_1f(_38,_2f).isXd){
_30.push("dojo/i18n!"+_38);
}
},loadInit:function(f){
f();
}};
try{
for(p in _33){
_31[p]=_1[p];
_1[p]=_33[p];
}
_2c.def.apply(null,_2e);
}
catch(e){
_62("error",[_f("failedDojoLoadInit"),e]);
}
finally{
for(p in _33){
_1[p]=_31[p];
}
}
_32.length&&_30.push("dojo/require!"+_32.join(","));
_2a(_30,function(){
_2b(1);
});
});
});
},_3b=function(_3c,_3d,_3e){
var _3f=/\(|\)/g,_40=1,_41;
_3f.lastIndex=_3d;
while((_41=_3f.exec(_3c))){
if(_41[0]==")"){
_40-=1;
}else{
_40+=1;
}
if(_40==0){
break;
}
}
if(_40!=0){
throw "unmatched paren around character "+_3f.lastIndex+" in: "+_3c;
}
return [_1.trim(_3c.substring(_3e,_3f.lastIndex))+";\n",_3f.lastIndex];
},_42=/(\/\*([\s\S]*?)\*\/|\/\/(.*)$)/mg,_43=/(^|\s)dojo\.(loadInit|require|provide|requireLocalization|requireIf|requireAfterIf|platformRequire)\s*\(/mg,_44=/(^|\s)(require|define)\s*\(/m,_45=function(_46,_47){
var _48,_49,_4a,_4b,_4c=[],_4d=[],_4e=[];
_47=_47||_46.replace(_42,function(_4f){
_43.lastIndex=_44.lastIndex=0;
return (_43.test(_4f)||_44.test(_4f))?"":_4f;
});
while((_48=_43.exec(_47))){
_49=_43.lastIndex;
_4a=_49-_48[0].length;
_4b=_3b(_47,_49,_4a);
if(_48[2]=="loadInit"){
_4c.push(_4b[0]);
}else{
_4d.push(_4b[0]);
}
_43.lastIndex=_4b[1];
}
_4e=_4c.concat(_4d);
if(_4e.length||!_44.test(_47)){
return [_46.replace(/(^|\s)dojo\.loadInit\s*\(/g,"\n0 && dojo.loadInit("),_4e.join(""),_4e];
}else{
return 0;
}
},_50=function(_51,_52){
var _53,id,_54=[],_55=[];
if(_12.test(_52)||!(_53=_45(_52))){
return 0;
}
id=_51.mid+"-*loadInit";
for(var p in _1f("dojo",_51).result.scopeMap){
_54.push(p);
_55.push("\""+p+"\"");
}
return "// xdomain rewrite of "+_51.path+"\n"+"define('"+id+"',{\n"+"\tnames:"+_1.toJson(_54)+",\n"+"\tdef:function("+_54.join(",")+"){"+_53[1]+"}"+"});\n\n"+"define("+_1.toJson(_54.concat(["dojo/loadInit!"+id]))+", function("+_54.join(",")+"){\n"+_53[0]+"});";
},_56=_3.initSyncLoader({load:_15},_21,_50,_9),_57=_56.sync,xd=_56.xd,_58=_56.requested,_59=_56.arrived,_5a=_56.nonmodule,_5b=_56.executing,_5c=_56.executed,_5d=_56.syncExecStack,_5e=_56.modules,_5f=_56.execQ,_60=_56.fixupUrl,_1f=_56.getModule,_20=_56.injectModule,_61=_56.setArrived,_62=_56.signal,_63=_56.finishExec,_64=_56.execModule,_65=_56.getLegacyMode;
_1.provide=function(mid){
var _66=_5d[0],_67=_6.mixin(_1f(_10(mid),_3.module),{executed:_5b,result:_6.getObject(mid,true)});
_61(_67);
if(_66){
(_66.provides||(_66.provides=[])).push(function(){
_67.result=_6.getObject(mid);
delete _67.provides;
_67.executed!==_5c&&_63(_67);
});
}
return _67.result;
};
_2.add("config-publishRequireResult",1,0,0);
_1.require=function(_68,_69){
function _6a(mid,_6b){
var _6c=_1f(_10(mid),_3.module);
if(_5d.length&&_5d[0].finish){
_5d[0].finish.push(mid);
return undefined;
}
if(_6c.executed){
return _6c.result;
}
_6b&&(_6c.result=_5a);
var _6d=_65();
_20(_6c);
if(_6c.executed!==_5c&&_6c.injected===_59){
_64(_6c);
}
if(_6c.executed){
return _6c.result;
}
if(_6d==_57){
if(_6c.cjs){
_5f.unshift(_6c);
}else{
_5d.length&&(_5d[0].finish=[mid]);
}
}else{
_5f.push(_6c);
}
return undefined;
};
var _6e=_6a(_68);
if(_2("config-publishRequireResult")&&!_6.exists(_68)&&_6e!==undefined){
_6.setObject(_68,_6e);
}
return _6e;
};
_1.loadInit=function(f){
f();
};
_1.registerModulePath=function(_6f,_70){
var _71={};
_71[_6f.replace(/\./g,"/")]=_70;
_3({paths:_71});
};
_1.platformRequire=function(_72){
var _73=(_72.common||[]).concat(_72[_1._name]||_72["default"]||[]),_74;
while(_73.length){
if(_6.isArray(_74=_73.shift())){
_1.require.apply(_1,_74);
}else{
_1.require(_74);
}
}
};
_1.requireIf=_1.requireAfterIf=function(_75,_76,_77){
if(_75){
_1.require(_76,_77);
}
};
_1.requireLocalization=function(_78,_79,_7a){
_3(["../i18n"],function(_7b){
_7b.getLocalization(_78,_79,_7a);
});
};
return {extractLegacyApiApplications:_45,require:_56.dojoRequirePlugin,loadInit:_29};
});
