define([], function(){
	return {
		price: 4,
		quantity: 3,
		save: function(){
			console.log("saving");
		}
	};
});