define([
	'./parser',
	'intern/node_modules/dojo/has!host-browser?./generate',
	'intern/node_modules/dojo/has!host-browser?./core',
	'intern/node_modules/dojo/has!host-browser?./base',
	'./expression'
], function(){});