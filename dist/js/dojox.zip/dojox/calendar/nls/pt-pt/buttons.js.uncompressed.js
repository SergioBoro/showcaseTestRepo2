define( "dojox/calendar/nls/pt-pt/buttons", {
	previousButton: "◄",
	nextButton: "►",
	todayButton: "Hoje",
	dayButton: "Dia",
	weekButton: "Semana",
	fourDaysButton: "4 dias",
	monthButton: "Mês"
}
);
