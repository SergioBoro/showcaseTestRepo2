//>>built
define("dojox/calendar/nls/sl/buttons",{previousButton:"◄",nextButton:"►",todayButton:"Danes",dayButton:"Dan",weekButton:"Teden",fourDaysButton:"4 dnevi",monthButton:"Mesec"});
