//>>built
define("dojox/calendar/nls/fi/buttons",{previousButton:"◄",nextButton:"►",todayButton:"Tänään",dayButton:"Päivä",weekButton:"Viikko",fourDaysButton:"4 päivää",monthButton:"Kuukausi"});
