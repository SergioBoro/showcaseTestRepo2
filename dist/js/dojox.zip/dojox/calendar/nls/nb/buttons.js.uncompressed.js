define( "dojox/calendar/nls/nb/buttons", {
	previousButton: "◄",
	nextButton: "►",
	todayButton: "I dag",
	dayButton: "Dag",
	weekButton: "Uke",
	fourDaysButton: "4 dager",
	monthButton: "Måned"
}
);
