//>>built
define("dojox/calendar/nls/de/buttons",{previousButton:"◄",nextButton:"►",todayButton:"Heute",dayButton:"Tag",weekButton:"Woche",fourDaysButton:"4 Tage",monthButton:"Monat"});
