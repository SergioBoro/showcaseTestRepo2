//>>built
define("dojox/cometd/longPollTransport",["dojo","dijit","dojox","dojo/require!dojox/cometd/longPollTransportJsonEncoded"],function(_1,_2,_3){
_1.provide("dojox.cometd.longPollTransport");
_1.require("dojox.cometd.longPollTransportJsonEncoded");
});
