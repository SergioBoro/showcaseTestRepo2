//>>built
define(["dijit","dojo","dojox","dojo/require!dojox/cometd/longPollTransportJsonEncoded"],function(_1,_2,_3){
_2.provide("dojox.cometd.longPollTransport");
_2.require("dojox.cometd.longPollTransportJsonEncoded");
});
