//>>built
define(["dijit","dojo","dojox","dojo/require!dojox/io/httpParse,dojox/cometd/RestChannels"],function(_1,_2,_3){
_2.provide("dojox.cometd.HttpChannels");
_2.require("dojox.io.httpParse");
_2.require("dojox.cometd.RestChannels");
_3.cometd.HttpChannels=_3.cometd.RestChannels;
});
