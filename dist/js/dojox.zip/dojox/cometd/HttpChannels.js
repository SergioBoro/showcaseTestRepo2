//>>built
define("dojox/cometd/HttpChannels",["dojo","dijit","dojox","dojo/require!dojox/io/httpParse,dojox/cometd/RestChannels"],function(_1,_2,_3){
_1.provide("dojox.cometd.HttpChannels");
_1.require("dojox.io.httpParse");
_1.require("dojox.cometd.RestChannels");
_3.cometd.HttpChannels=_3.cometd.RestChannels;
});
