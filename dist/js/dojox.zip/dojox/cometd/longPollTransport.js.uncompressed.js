//>>built
// wrapped by build app
define("dojox/cometd/longPollTransport", ["dijit","dojo","dojox","dojo/require!dojox/cometd/longPollTransportJsonEncoded"], function(dijit,dojo,dojox){
dojo.provide("dojox.cometd.longPollTransport");
dojo.require("dojox.cometd.longPollTransportJsonEncoded");

});
