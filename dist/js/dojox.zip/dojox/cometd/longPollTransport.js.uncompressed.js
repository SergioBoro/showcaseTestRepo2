//>>built
// wrapped by build app
define("dojox/cometd/longPollTransport", ["dojo","dijit","dojox","dojo/require!dojox/cometd/longPollTransportJsonEncoded"], function(dojo,dijit,dojox){
dojo.provide("dojox.cometd.longPollTransport");
dojo.require("dojox.cometd.longPollTransportJsonEncoded");

});
