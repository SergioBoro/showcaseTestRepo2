//>>built
define([],{names:["dijit","dojo","dojox"],def:function(_1,_2,_3){
_2.provide("dojox.cometd.RestChannels");
_2.require("dojox.rpc.Client");
_2.require("dojo._base.url");
_2.requireIf(_3.data&&!!_3.data.JsonRestStore,"dojox.data.restListener");
}});
