//>>built
define("dojox/analytics", ["./analytics/_base"], function(analytics) {
	return analytics;
});
