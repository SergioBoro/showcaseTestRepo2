//>>built
define("dojox/cometd",["dojo","dijit","dojox","dojo/require!dojox/cometd/_base,dojox/cometd/longPollTransport,dojox/cometd/callbackPollTransport"],function(_1,_2,_3){
_1.provide("dojox.cometd");
_1.require("dojox.cometd._base");
_1.require("dojox.cometd.longPollTransport");
_1.require("dojox.cometd.callbackPollTransport");
});
