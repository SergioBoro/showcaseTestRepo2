//>>built
define("dojox/color", ["./color/_base"], function(dxcolor){
	return dxcolor;
});
