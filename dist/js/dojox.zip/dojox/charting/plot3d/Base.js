//>>built
define("dojox/charting/plot3d/Base",["dojo/_base/declare"],function(_1){
return _1("dojox.charting.plot3d.Base",null,{constructor:function(_2,_3,_4){
this.width=_2;
this.height=_3;
},setData:function(_5){
this.data=_5?_5:[];
return this;
},getDepth:function(){
return this.depth;
},generate:function(_6,_7){
}});
});
