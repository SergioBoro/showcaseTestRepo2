//>>built
define("dojox/charting/plot2d/Markers",["dojo/_base/declare","./Default"],function(_1,_2){
return _1("dojox.charting.plot2d.Markers",_2,{constructor:function(){
this.opt.markers=true;
}});
});
