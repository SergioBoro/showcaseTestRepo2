//>>built
define("dojox/charting/plot2d/Lines",["dojo/_base/declare","./Default"],function(_1,_2){
return _1("dojox.charting.plot2d.Lines",_2,{constructor:function(){
this.opt.lines=true;
}});
});
