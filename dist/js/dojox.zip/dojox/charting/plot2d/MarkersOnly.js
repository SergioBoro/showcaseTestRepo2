//>>built
define("dojox/charting/plot2d/MarkersOnly",["dojo/_base/declare","./Default"],function(_1,_2){
return _1("dojox.charting.plot2d.MarkersOnly",_2,{constructor:function(){
this.opt.lines=false;
this.opt.markers=true;
}});
});
