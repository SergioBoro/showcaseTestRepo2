//>>built
define("dojox/charting/plot2d/StackedLines",["dojo/_base/declare","./Stacked"],function(_1,_2){
return _1("dojox.charting.plot2d.StackedLines",_2,{constructor:function(){
this.opt.lines=true;
}});
});
