//>>built
define("dojox/charting/plot2d/StackedAreas",["dojo/_base/declare","./Stacked"],function(_1,_2){
return _1("dojox.charting.plot2d.StackedAreas",_2,{constructor:function(){
this.opt.lines=true;
this.opt.areas=true;
}});
});
