//>>built
define("dojox/charting/plot2d/Areas",["dojo/_base/declare","./Default"],function(_1,_2){
return _1("dojox.charting.plot2d.Areas",_2,{constructor:function(){
this.opt.lines=true;
this.opt.areas=true;
}});
});
