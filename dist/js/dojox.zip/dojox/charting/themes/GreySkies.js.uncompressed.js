//>>built
define("dojox/charting/themes/GreySkies", ["../Theme", "./common"], function(Theme, themes){
	
	themes.GreySkies=new Theme(Theme._def);
	
	return themes.GreySkies;
});
