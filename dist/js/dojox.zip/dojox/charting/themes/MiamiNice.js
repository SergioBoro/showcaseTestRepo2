//>>built
define("dojox/charting/themes/MiamiNice",["../Theme","./common"],function(_1,_2){
_2.MiamiNice=new _1({colors:["#7f9599","#45b8cc","#8ecfb0","#f8acac","#cc4482"]});
return _2.MiamiNice;
});
