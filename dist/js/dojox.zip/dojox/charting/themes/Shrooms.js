//>>built
define("dojox/charting/themes/Shrooms",["../Theme","./common"],function(_1,_2){
_2.Shrooms=new _1({colors:["#bf1313","#69bf13","#13bfbf","#6913bf","#bf6913","#13bf13","#1369bf","#bf13bf","#bfbf13","#13bf69","#1313bf","#bf1369"]});
return _2.Shrooms;
});
