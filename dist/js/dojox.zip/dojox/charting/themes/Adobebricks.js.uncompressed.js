//>>built
define("dojox/charting/themes/Adobebricks", ["../Theme", "./common"], function(Theme, themes){

	themes.Adobebricks=new Theme({
		colors: [
			"#7f2518",
			"#3e170c",
			"#cc3927",
			"#651f0e",
			"#8c271c"
		]
	});
	
	return themes.Adobebricks;
});
