//>>built
define("dojox/charting/themes/MiamiNice", ["../Theme", "./common"], function(Theme, themes){
	
	themes.MiamiNice=new Theme({
		colors: [
			"#7f9599",
			"#45b8cc",
			"#8ecfb0",
			"#f8acac",
			"#cc4482"
		]
	});
	
	return themes.MiamiNice;
});
