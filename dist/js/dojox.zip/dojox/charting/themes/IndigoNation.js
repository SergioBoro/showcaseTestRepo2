//>>built
define("dojox/charting/themes/IndigoNation",["../Theme","./common"],function(_1,_2){
_2.IndigoNation=new _1({colors:["#93a4d0","#3b4152","#687291","#9faed9","#8290b8"]});
return _2.IndigoNation;
});
