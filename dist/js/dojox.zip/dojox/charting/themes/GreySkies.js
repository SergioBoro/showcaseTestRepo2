//>>built
define("dojox/charting/themes/GreySkies",["../Theme","./common"],function(_1,_2){
_2.GreySkies=new _1(_1._def);
return _2.GreySkies;
});
