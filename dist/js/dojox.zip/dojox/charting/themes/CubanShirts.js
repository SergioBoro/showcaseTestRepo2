//>>built
define("dojox/charting/themes/CubanShirts",["../Theme","./common"],function(_1,_2){
_2.CubanShirts=new _1({colors:["#d42d2a","#004f80","#989736","#2085c7","#7f7f33"]});
return _2.CubanShirts;
});
