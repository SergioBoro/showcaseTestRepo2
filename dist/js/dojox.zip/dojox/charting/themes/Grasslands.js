//>>built
define("dojox/charting/themes/Grasslands",["../Theme","./common"],function(_1,_2){
_2.Grasslands=new _1({colors:["#70803a","#dde574","#788062","#b1cc5d","#eff2c2"]});
return _2.Grasslands;
});
