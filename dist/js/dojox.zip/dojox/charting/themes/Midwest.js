//>>built
define("dojox/charting/themes/Midwest",["../Theme","./common"],function(_1,_2){
_2.Midwest=new _1({colors:["#927b51","#a89166","#80c31c","#bcdd5a","#aebc21"]});
return _2.Midwest;
});
