//>>built
define("dojox/charting/themes/Ireland",["../Theme","./common"],function(_1,_2){
_2.Ireland=new _1({colors:["#abdbcb","#435a51","#70998b","#78d596","#5f8074"]});
return _2.Ireland;
});
