//>>built
define("dojox/charting/themes/SageToLime",["../Theme","./common"],function(_1,_2){
_2.SageToLime=new _1({colors:["#abdbcb","#435a51","#70998b","#5f8074","#80ccbb","#539e8b","#78a596","#335f54","#8dd1c2","#68c5ad"]});
return _2.SageToLime;
});
