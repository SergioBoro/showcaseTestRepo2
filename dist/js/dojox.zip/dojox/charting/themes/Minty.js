//>>built
define("dojox/charting/themes/Minty",["../Theme","./common"],function(_1,_2){
_2.Minty=new _1({colors:["#80ccbb","#539e8b","#335f54","#8dd1c2","#68c5ad"]});
return _2.Minty;
});
