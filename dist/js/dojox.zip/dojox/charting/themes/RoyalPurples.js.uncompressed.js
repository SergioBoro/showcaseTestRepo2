//>>built
define("dojox/charting/themes/RoyalPurples", ["../Theme", "./common"], function(Theme, themes){
	
	themes.RoyalPurples=new Theme({
		colors: [
			"#473980",
			"#685aa7",
			"#7970b3",
			"#231c3f",
			"#7267ae"
		]
	});
	
	return themes.RoyalPurples;
});
