//>>built
define("dojox/charting/themes/Bahamation",["../Theme","./common"],function(_1,_2){
_2.Bahamation=new _1({colors:["#3f9998","#3fc0c3","#70c058","#ef446f","#c663a6"]});
return _2.Bahamation;
});
