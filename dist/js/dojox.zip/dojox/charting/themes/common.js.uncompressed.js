//>>built
define("dojox/charting/themes/common", ["dojo/_base/lang"], function(lang){
	return lang.getObject("dojox.charting.themes", true);
});
