//>>built
define("dojox/charting/themes/Grasshopper", ["dojo/_base/lang","../Theme", "./common"], function(lang, Theme, themes){
	themes.Grasshopper=new Theme({
		colors: [
			"#208040",
			"#40b657",
			"#78c25e",
			"#14401f",
			"#64bd5f"
		]
	});
	return themes.Grasshopper;
});
