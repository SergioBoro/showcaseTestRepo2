//>>built
define("dojox/charting/themes/Minty", ["../Theme", "./common"], function(Theme, themes){
	
	themes.Minty=new Theme({
		colors: [
			"#80ccbb",
			"#539e8b",
			"#335f54",
			"#8dd1c2",
			"#68c5ad"
		]
	});
	
	return themes.Minty;
});
