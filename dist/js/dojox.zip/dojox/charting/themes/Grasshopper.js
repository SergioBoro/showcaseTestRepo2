//>>built
define("dojox/charting/themes/Grasshopper",["dojo/_base/lang","../Theme","./common"],function(_1,_2,_3){
_3.Grasshopper=new _2({colors:["#208040","#40b657","#78c25e","#14401f","#64bd5f"]});
return _3.Grasshopper;
});
