//>>built
define("dojox/charting/themes/Desert",["../Theme","./common"],function(_1,_2){
_2.Desert=new _1({colors:["#ffebd5","#806544","#fdc888","#80766b","#cda26e"]});
return _2.Desert;
});
