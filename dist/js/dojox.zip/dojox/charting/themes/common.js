//>>built
define("dojox/charting/themes/common",["dojo/_base/lang"],function(_1){
return _1.getObject("dojox.charting.themes",true);
});
