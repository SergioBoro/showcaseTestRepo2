//>>built
define("dojox/charting/themes/Wetland",["../Theme","./common"],function(_1,_2){
_2.Wetland=new _1({colors:["#bfbc64","#737130","#73373b","#7dafca","#8d3c42"]});
return _2.Wetland;
});
