//>>built
define("dojox/charting/themes/PurpleRain",["../Theme","./common"],function(_1,_2){
_2.PurpleRain=new _1({colors:["#4879bc","#ef446f","#3f58a7","#8254a2","#4956a6"]});
return _2.PurpleRain;
});
