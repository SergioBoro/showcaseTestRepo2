//>>built
define("dojox/charting/themes/Adobebricks",["../Theme","./common"],function(_1,_2){
_2.Adobebricks=new _1({colors:["#7f2518","#3e170c","#cc3927","#651f0e","#8c271c"]});
return _2.Adobebricks;
});
