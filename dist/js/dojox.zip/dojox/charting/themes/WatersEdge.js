//>>built
define("dojox/charting/themes/WatersEdge",["../Theme","./common"],function(_1,_2){
_2.WatersEdge=new _1({colors:["#437cc0","#6256a5","#4552a3","#43c4f2","#4b66b0"]});
return _2.WatersEdge;
});
