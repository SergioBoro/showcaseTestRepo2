//>>built
define("dojox/charting/themes/BlueDusk",["../Theme","./common"],function(_1,_2){
_2.BlueDusk=new _1({colors:["#292e76","#3e56a6","#10143f","#33449c","#798dcd"]});
return _2.BlueDusk;
});
