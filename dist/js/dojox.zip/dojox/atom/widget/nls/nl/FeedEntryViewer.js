//>>built
define(
//begin v1.x content
({
	displayOptions: "[weergaveopties]",
	title: "Titel",
	authors: "Auteurs",
	contributors: "Deelnemers",
	id: "ID",
	close: "[sluiten]",
	updated: "Bijgewerkt",
	summary: "Overzicht",
	content: "Content"
})
//end v1.x content
);
