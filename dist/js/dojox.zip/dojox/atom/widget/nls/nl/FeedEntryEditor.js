//>>built
define(
//begin v1.x content
({
	doNew: "[nieuw]",
	edit: "[bewerken]",
	save: "[opslaan]",
	cancel: "[annuleren]"
})
//end v1.x content
);
