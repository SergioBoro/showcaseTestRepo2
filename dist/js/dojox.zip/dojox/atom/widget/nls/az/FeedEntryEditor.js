//>>built
define(
//begin v1.x content
({
	"edit" : "[tərtib et]",
	"save" : "[saxla]",
	"cancel" : "[ləğv et]",
	"doNew" : "[yeni]"
})
//end v1.x content
);