//>>built
define("dojox/atom/widget/nls/az/FeedEntryEditor",({"edit":"[tərtib et]","save":"[saxla]","cancel":"[ləğv et]","doNew":"[yeni]"}));
