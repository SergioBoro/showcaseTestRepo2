//>>built
define(
//begin v1.x content
({
	"close" : "[çıx]",
	"title" : "Başlıq",
	"authors" : "Yazıçılar",
	"summary" : "Məzmun",
	"content" : "Tərkib",
	"contributors" : "Əməyi keçənlər",
	"updated" : "Yeniləndi",
	"displayOptions" : "[göstərmə seçimləri]",
	"id" : "Şəxsiyyət"
})
//end v1.x content
);