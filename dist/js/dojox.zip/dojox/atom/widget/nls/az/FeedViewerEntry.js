//>>built
define(
//begin v1.x content
({
	"deleteButton" : "[Sil]"
})
//end v1.x content
);