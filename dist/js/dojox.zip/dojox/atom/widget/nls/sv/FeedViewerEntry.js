//>>built
define(
//begin v1.x content
({
	deleteButton: "[Ta bort]"
})
//end v1.x content
);
