//>>built
define("dojox/atom/widget/nls/uk/FeedViewerEntry",({deleteButton:"[Видалити]"}));
