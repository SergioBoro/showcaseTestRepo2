//>>built
define(
//begin v1.x content
({
	add: "Ekle",
	addAuthor: "Yazar Ekle",
	addContributor: "Katkıda Bulunan Ekle"
})
//end v1.x content
);
