//>>built
define("dojox/atom/widget/nls/tr/PeopleEditor",({add:"Ekle",addAuthor:"Yazar Ekle",addContributor:"Katkıda Bulunan Ekle"}));
