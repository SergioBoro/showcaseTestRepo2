//>>built
define("dojox/atom/widget/nls/tr/FeedEntryEditor",({doNew:"[yeni]",edit:"[düzenle]",save:"[kaydet]",cancel:"[iptal]"}));
