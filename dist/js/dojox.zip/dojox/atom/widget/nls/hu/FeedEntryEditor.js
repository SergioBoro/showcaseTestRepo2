//>>built
define(
//begin v1.x content
({
	doNew: "[új]",
	edit: "[szerkesztés]",
	save: "[mentés]",
	cancel: "[mégse]"
})
//end v1.x content
);
