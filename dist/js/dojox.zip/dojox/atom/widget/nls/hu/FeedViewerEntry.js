//>>built
define(
//begin v1.x content
({
	deleteButton: "[Törlés]"
})
//end v1.x content
);
