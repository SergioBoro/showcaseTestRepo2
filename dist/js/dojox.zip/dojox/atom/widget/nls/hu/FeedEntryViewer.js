//>>built
define(
//begin v1.x content
({
	displayOptions: "[megjelenítési beállítások]",
	title: "Cím",
	authors: "Szerzők",
	contributors: "Közreműködők",
	id: "Azonosító",
	close: "[bezárás]",
	updated: "Frissítve",
	summary: "Összegzés",
	content: "Tartalom"
})
//end v1.x content
);
