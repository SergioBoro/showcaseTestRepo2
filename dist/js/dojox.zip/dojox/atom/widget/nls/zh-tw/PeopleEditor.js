//>>built
define(
//begin v1.x content
({
	add: "新增",
	addAuthor: "新增作者",
	addContributor: "新增貢獻者"
})
//end v1.x content
);
