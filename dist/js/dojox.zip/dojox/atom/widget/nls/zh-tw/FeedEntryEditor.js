//>>built
define("dojox/atom/widget/nls/zh-tw/FeedEntryEditor",({doNew:"[新建]",edit:"[編輯]",save:"[儲存]",cancel:"[取消]"}));
