//>>built
define(
//begin v1.x content
({
	doNew: "[新建]",
	edit: "[編輯]",
	save: "[儲存]",
	cancel: "[取消]"
})
//end v1.x content
);
