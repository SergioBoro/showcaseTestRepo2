//>>built
define(
//begin v1.x content
({
	displayOptions: "[visningsalternativer]",
	title: "Tittel",
	authors: "Forfattere",
	contributors: "Bidragsytere",
	id: "ID",
	close: "[lukk]",
	updated: "Oppdatert",
	summary: "Sammendrag",
	content: "Innhold"
})
//end v1.x content
);
