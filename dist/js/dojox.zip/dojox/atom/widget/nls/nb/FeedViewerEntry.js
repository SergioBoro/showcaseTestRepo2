//>>built
define(
//begin v1.x content
({
	deleteButton: "[Slett]"
})
//end v1.x content
);
