//>>built
define(
//begin v1.x content
({
	add: "Legg til",
	addAuthor: "Legg til forfatter",
	addContributor: "Legg til bidragsyter"
})
//end v1.x content
);
