//>>built
define("dojox/atom/widget/nls/nb/PeopleEditor",({add:"Legg til",addAuthor:"Legg til forfatter",addContributor:"Legg til bidragsyter"}));
