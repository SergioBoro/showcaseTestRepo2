//>>built
define(
//begin v1.x content
({
	doNew: "[ny(tt)]",
	edit: "[rediger]",
	save: "[lagre]",
	cancel: "[avbryt]"
})
//end v1.x content
);
