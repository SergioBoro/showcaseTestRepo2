//>>built
define(
//begin v1.x content
({
	deleteButton: "[Poista]"
})
//end v1.x content
);
