//>>built
define(
//begin v1.x content
({
	displayOptions: "[näyttöasetukset]",
	title: "Otsikko",
	authors: "Tekijät",
	contributors: "Lisääjät",
	id: "Tunnus",
	close: "[sulje]",
	updated: "Päivitetty",
	summary: "Tiivistelmä",
	content: "Sisältö"
})
//end v1.x content
);
