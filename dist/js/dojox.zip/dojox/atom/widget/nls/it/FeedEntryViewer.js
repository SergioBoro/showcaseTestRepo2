//>>built
define(
//begin v1.x content
({
	displayOptions: "[visualizza opzioni]",
	title: "Titolo",
	authors: "Autori",
	contributors: "Collaboratori",
	id: "ID",
	close: "[chiudi]",
	updated: "Aggiornato",
	summary: "Riepilogo",
	content: "Indice"
})
//end v1.x content
);
