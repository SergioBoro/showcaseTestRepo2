//>>built
define(
//begin v1.x content
({
	add: "Aggiungi",
	addAuthor: "Aggiungi autore",
	addContributor: "Aggiungi collaboratori"
})
//end v1.x content
);
