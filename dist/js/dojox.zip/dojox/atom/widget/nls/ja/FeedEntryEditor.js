//>>built
define(
//begin v1.x content
({
	doNew: "[新規]",
	edit: "[編集]",
	save: "[保存]",
	cancel: "[キャンセル]"
})
//end v1.x content
);
