//>>built
define(
//begin v1.x content
({
	add: "添加",
	addAuthor: "添加作者",
	addContributor: "添加内容添加者"
})
//end v1.x content
);
