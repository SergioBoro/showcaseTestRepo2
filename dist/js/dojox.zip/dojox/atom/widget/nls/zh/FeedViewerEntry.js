//>>built
define("dojox/atom/widget/nls/zh/FeedViewerEntry",({deleteButton:"[删除]"}));
