define(
"dojox/atom/widget/nls/sl/FeedEntryEditor", ({
	doNew: "[novo]",
	edit: "[urejanje]",
	save: "[shrani]",
	cancel: "[prekliči]"
})
);
