//>>built
define(
//begin v1.x content
({
	add: "เพิ่ม",
	addAuthor: "เพิ่มผู้เขียน",
	addContributor: "เพิ่มผู้อนุเคราะห์"
})
//end v1.x content
);
