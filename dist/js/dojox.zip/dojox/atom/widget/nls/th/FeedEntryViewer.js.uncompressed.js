define(
"dojox/atom/widget/nls/th/FeedEntryViewer", ({
	displayOptions: "[แสดงอ็อพชัน]",
	title: "หัวเรื่อง",
	authors: "ผู้เขียน",
	contributors: "ผู้ร่วมให้ข้อมูล",
	id: "ID",
	close: "[ปิด]",
	updated: "อัพเดต",
	summary: "ยอดรวม",
	content: "เนื้อหา"
})
);
