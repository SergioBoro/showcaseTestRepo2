//>>built
define(
//begin v1.x content
({
	displayOptions: "[อ็อพชันการแสดงผล]",
	title: "ชื่อเรื่อง",
	authors: "ผู้เขียน",
	contributors: "ผู้อนุเคราะห์",
	id: "ID",
	close: "[ปิด]",
	updated: "อัพเดต",
	summary: "สรุป",
	content: "เนื้อหา"
})
//end v1.x content
);
