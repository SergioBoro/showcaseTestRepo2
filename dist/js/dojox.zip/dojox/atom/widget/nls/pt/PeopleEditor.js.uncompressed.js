define(
"dojox/atom/widget/nls/pt/PeopleEditor", ({
	add: "Incluir",
	addAuthor: "Adicionar Autor",
	addContributor: "Adicionar Contribuidor"
})
);
