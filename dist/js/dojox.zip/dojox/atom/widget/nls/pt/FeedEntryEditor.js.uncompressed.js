define(
"dojox/atom/widget/nls/pt/FeedEntryEditor", ({
	doNew: "[novo]",
	edit: "[editar]",
	save: "[salvar]",
	cancel: "[cancelar]"
})
);
