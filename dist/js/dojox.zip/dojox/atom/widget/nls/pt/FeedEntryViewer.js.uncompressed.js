define(
"dojox/atom/widget/nls/pt/FeedEntryViewer", ({
	displayOptions: "[exibir opções]",
	title: "Título",
	authors: "Autores",
	contributors: "Contribuidores",
	id: "ID",
	close: "[fechar]",
	updated: "Atualizado",
	summary: "Resumo",
	content: "Conteúdo"
})
);
