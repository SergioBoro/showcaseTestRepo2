//>>built
define(
//begin v1.x content
({
	add: "Adicionar",
	addAuthor: "Adicionar Autor",
	addContributor: "Adicionar Contribuidor"
})
//end v1.x content
);
