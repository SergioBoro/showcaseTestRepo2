//>>built
define(
//begin v1.x content
({
	add: "Ajouter",
	addAuthor: "Ajouter un auteur",
	addContributor: "Ajouter un collaborateur"
})
//end v1.x content
);
