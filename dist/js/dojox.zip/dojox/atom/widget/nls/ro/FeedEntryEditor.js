//>>built
define(
//begin v1.x content
({
	doNew: "[nou]",
	edit: "[editare]",
	save: "[salvare]",
	cancel: "[anulare]"
})
//end v1.x content
);
