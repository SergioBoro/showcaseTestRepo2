//>>built
define(
//begin v1.x content
({
	deleteButton: "[Ştergere]"
})
//end v1.x content
);
