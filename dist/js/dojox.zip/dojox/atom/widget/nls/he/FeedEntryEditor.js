//>>built
define(
//begin v1.x content
({
	doNew: "[חדש]",
	edit: "[עריכה]",
	save: "[שמירה]",
	cancel: "[ביטול]"
})
//end v1.x content
);
