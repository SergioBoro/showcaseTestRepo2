//>>built
define(
//begin v1.x content
({
	add: "הוספה",
	addAuthor: "הוספת מחבר",
	addContributor: "הוספת תורם"
})
//end v1.x content
);
