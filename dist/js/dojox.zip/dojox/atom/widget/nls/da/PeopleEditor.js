//>>built
define(
//begin v1.x content
({
	add: "Tilføj",
	addAuthor: "Tilføj forfatter",
	addContributor: "Tilføj bidragyder"
})
//end v1.x content
);
