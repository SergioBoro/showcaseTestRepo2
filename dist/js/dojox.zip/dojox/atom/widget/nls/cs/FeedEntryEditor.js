//>>built
define(
//begin v1.x content
({
	doNew: "[nové]",
	edit: "[upravit]",
	save: "[uložit]",
	cancel: "[storno]"
})
//end v1.x content
);
