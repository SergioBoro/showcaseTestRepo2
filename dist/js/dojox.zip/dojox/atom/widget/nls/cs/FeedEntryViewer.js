//>>built
define(
//begin v1.x content
({
	displayOptions: "[volby zobrazení]",
	title: "Název",
	authors: "Autoři",
	contributors: "Přispěvatelé",
	id: "ID",
	close: "[zavřít]",
	updated: "Aktualizováno",
	summary: "Souhrn",
	content: "Obsah"
})
//end v1.x content
);
