//>>built
define(
//begin v1.x content
({
	add: "Hinzufügen",
	addAuthor: "Autor hinzufügen",
	addContributor: "Mitwirkenden hinzufügen"
})
//end v1.x content
);
