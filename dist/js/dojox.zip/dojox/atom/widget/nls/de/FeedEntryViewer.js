//>>built
define(
//begin v1.x content
({
	displayOptions: "[Anzeigeoptionen]",
	title: "Titel",
	authors: "Autoren",
	contributors: "Mitwirkende",
	id: "ID",
	close: "[Schließen]",
	updated: "Aktualisiert",
	summary: "Zusammenfassung",
	content: "Inhalt"
})
//end v1.x content
);
