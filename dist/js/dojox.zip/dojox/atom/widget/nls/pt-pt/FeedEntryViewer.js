//>>built
define(
//begin v1.x content
({
	displayOptions: "[opções de visualização]",
	title: "Título",
	authors: "Autores",
	contributors: "Contribuintes",
	id: "ID",
	close: "[fechar]",
	updated: "Actualizado",
	summary: "Resumo",
	content: "Conteúdo"
})
//end v1.x content
);
