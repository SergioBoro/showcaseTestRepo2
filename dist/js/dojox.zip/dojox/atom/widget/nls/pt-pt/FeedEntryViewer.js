//>>built
define("dojox/atom/widget/nls/pt-pt/FeedEntryViewer",({displayOptions:"[opções de visualização]",title:"Título",authors:"Autores",contributors:"Contribuintes",id:"ID",close:"[fechar]",updated:"Actualizado",summary:"Resumo",content:"Conteúdo"}));
