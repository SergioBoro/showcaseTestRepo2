//>>built
define(
//begin v1.x content
({
	deleteButton: "[Eliminar]"
})
//end v1.x content
);
