//>>built
define("dojox/atom/widget/nls/pl/PeopleEditor",({add:"Dodaj",addAuthor:"Dodaj autora",addContributor:"Dodaj kontrybutora"}));
