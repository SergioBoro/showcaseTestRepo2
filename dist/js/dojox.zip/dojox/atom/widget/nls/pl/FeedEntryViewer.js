//>>built
define(
//begin v1.x content
({
	displayOptions: "[opcje wyświetlania]",
	title: "Tytuł",
	authors: "Autorzy",
	contributors: "Kontrybutorzy",
	id: "Identyfikator",
	close: "[zamknij]",
	updated: "Zaktualizowano",
	summary: "Podsumowanie",
	content: "Treść"
})
//end v1.x content
);
