//>>built
define(
//begin v1.x content
({
	deleteButton: "[Usuń]"
})
//end v1.x content
);
