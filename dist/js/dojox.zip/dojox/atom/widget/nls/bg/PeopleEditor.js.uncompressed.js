define(
"dojox/atom/widget/nls/bg/PeopleEditor", ({
	add: "Добави",
	addAuthor: "Добави автор",
	addContributor: "Добави сътрудник"
})
);
