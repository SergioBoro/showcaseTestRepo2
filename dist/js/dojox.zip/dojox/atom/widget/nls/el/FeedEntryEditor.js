//>>built
define(
//begin v1.x content
({
	doNew: "[δημιουργία]",
	edit: "[τροποποίηση]",
	save: "[αποθήκευση]",
	cancel: "[ακύρωση]"
})
//end v1.x content
);
