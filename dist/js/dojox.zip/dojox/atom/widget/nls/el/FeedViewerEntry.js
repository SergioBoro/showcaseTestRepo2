//>>built
define(
//begin v1.x content
({
	deleteButton: "[Διαγραφή]"
})
//end v1.x content
);
