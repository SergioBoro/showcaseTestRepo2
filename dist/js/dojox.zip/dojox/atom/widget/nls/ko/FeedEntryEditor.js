//>>built
define(
//begin v1.x content
({
	doNew: "[새로 작성]",
	edit: "[편집]",
	save: "[저장]",
	cancel: "[취소]"
})
//end v1.x content
);
