//>>built
define(
//begin v1.x content
({
	displayOptions: "[옵션 표시]",
	title: "제목",
	authors: "작성자",
	contributors: "기고자",
	id: "ID",
	close: "[닫기]",
	updated: "업데이트된 날짜",
	summary: "요약",
	content: "컨텐츠"
})
//end v1.x content
);
