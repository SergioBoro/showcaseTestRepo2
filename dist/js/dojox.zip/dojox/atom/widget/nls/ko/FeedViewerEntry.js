//>>built
define(
//begin v1.x content
({
	deleteButton: "[삭제]"
})
//end v1.x content
);
