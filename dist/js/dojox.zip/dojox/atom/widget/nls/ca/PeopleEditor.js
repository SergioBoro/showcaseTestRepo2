//>>built
define(
//begin v1.x content
({
	add: "Afegeix",
	addAuthor: "Afegeix un autor",
	addContributor: "Afegeix un col·laborador"
})
//end v1.x content
);
