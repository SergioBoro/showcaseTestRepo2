//>>built
define(
//begin v1.x content
({
	doNew: "[создать]",
	edit: "[изменить]",
	save: "[сохранить]",
	cancel: "[отмена]"
})
//end v1.x content
);
