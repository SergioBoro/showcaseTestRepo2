//>>built
define(
//begin v1.x content
({
	add: "اضافة",
	addAuthor: "اضافة مؤلف",
	addContributor: "اضافة مشارك"
})
//end v1.x content
);
