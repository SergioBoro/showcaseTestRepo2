//>>built
define(
//begin v1.x content
({
	doNew: "[جديد]",
	edit: "[تحرير]",
	save: "[حفظ]",
	cancel: "[الغاء]"
})
//end v1.x content
);
