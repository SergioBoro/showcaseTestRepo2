//>>built
define(
//begin v1.x content
({
	deleteButton: "[حذف]"
})
//end v1.x content
);
