//>>built
define("dojox/app/main",["dojo/_base/kernel","dojo/_base/lang","dojo/_base/declare","dojo/ready","dojo/_base/window","dojo/dom-construct","dijit","dojox","dojo/cache","dojo/fx","dojox/json/ref","dojo/parser","./scene","dojox/mobile/transition","dojo/on"],function(_1,_2,_3,_4,_5,_6,_7,_8,_9,fx,_a,_b,_c,_d,_e){
_1.experimental("dojox.app");
var _f=_3([_c],{constructor:function(_10){
this.scenes={};
if(_10.stores){
for(var _11 in _10.stores){
if(_11.charAt(0)!=="_"){
var _12=_10.stores[_11].type?_10.stores[_11].type:"dojo.store.Memory";
var _13={};
if(_10.stores[_11].params){
_1.mixin(_13,_10.stores[_11].params);
}
var _14=_1.getObject(_12);
if(_13.data&&_2.isString(_13.data)){
_13.data=_1.getObject(_13.data);
}
_10.stores[_11].store=new _14(_13);
}
}
}
},templateString:"<div></div>",selectedChild:null,baseClass:"application mblView",defaultViewType:_c,buildRendering:function(){
if(this.srcNodeRef===_5.body()){
this.srcNodeRef=_6.create("DIV",{},_5.body());
}
this.inherited(arguments);
}});
function _15(_16,_17,_18,_19){
var _1a=_16.modules.concat(_16.dependencies);
if(_16.template){
_1a.push("dojo/text!"+"app/"+_16.template);
}
require(_1a,function(){
var _1b=[_f];
for(var i=0;i<_16.modules.length;i++){
_1b.push(arguments[i]);
}
if(_16.template){
var ext={templateString:arguments[arguments.length-1]};
}
App=_3(_1b,ext);
_4(function(){
app=App(_16,_17||_5.body());
app.startup();
});
});
};
return function(_1c,_1d){
if(!_1c){
throw Error("App Config Missing");
}
if(_1c.validate){
require(["dojox/json/schema","dojox/json/ref","dojo/text!dojox/application/schema/application.json"],function(_1e,_1f){
_1e=dojox.json.ref.resolveJson(_1e);
if(_1e.validate(_1c,_1f)){
_15(_1c,_1d);
}
});
}else{
_15(_1c,_1d);
}
};
});
