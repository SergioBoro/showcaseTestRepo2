//>>built
define("dojox/app/scene",["dojo/_base/kernel","dojo/_base/declare","dojo/_base/array","dojo/_base/Deferred","dojo/_base/lang","dojo/_base/sniff","dojo/dom-style","dojo/dom-geometry","dojo/dom-class","dojo/dom-construct","dojo/dom-attr","dojo/query","dijit","dojox","dijit/_WidgetBase","dijit/_TemplatedMixin","dijit/_WidgetsInTemplateMixin","./transition","./animation","./model","./view","./bind"],function(_1,_2,_3,_4,_5,_6,_7,_8,_9,_a,_b,_c,_d,_e,_f,_10,_11,_12,_13,_14,_15,_16){
var _17=function(_18,mb){
var cs=_7.getComputedStyle(_18);
var me=_8.getMarginExtents(_18,cs);
var pb=_8.getPadBorderExtents(_18,cs);
return {l:_7.toPixelValue(_18,cs.paddingLeft),t:_7.toPixelValue(_18,cs.paddingTop),w:mb.w-(me.w+pb.w),h:mb.h-(me.h+pb.h)};
};
var _19=function(_1a){
return _1a.substring(0,1).toUpperCase()+_1a.substring(1);
};
var _1b=function(_1c,dim){
var _1d=_1c.resize?_1c.resize(dim):_8.setMarginBox(_1c.domNode,dim);
if(_1d){
_1.mixin(_1c,_1d);
}else{
_1.mixin(_1c,_8.getMarginBox(_1c.domNode));
_1.mixin(_1c,dim);
}
};
return _2("dojox.app.scene",[_d._WidgetBase,_d._TemplatedMixin,_d._WidgetsInTemplateMixin],{isContainer:true,widgetsInTemplate:true,defaultView:"default",selectedChild:null,baseClass:"scene mblView",isFullScreen:false,defaultViewType:_15,getParent:function(){
return null;
},constructor:function(_1e,_1f){
this.children={};
if(_1e.parent){
this.parent=_1e.parent;
}
if(_1e.app){
this.app=_1e.app;
}
},buildRendering:function(){
this.inherited(arguments);
_7.set(this.domNode,{width:"100%","height":"100%"});
_9.add(this.domNode,"dijitContainer");
},splitChildRef:function(_20){
var id=_20.split(",");
if(id.length>0){
var to=id.shift();
}else{
console.warn("invalid child id passed to splitChildRef(): ",_20);
}
return {id:to||this.defaultView,next:id.join(",")};
},loadChild:function(_21,_22,_23){
if(!_22){
return error("Child ID: '"+_22+"' not found");
}
var cid=_21.id+"_"+_22;
if(_21.children[cid]){
return _21.children[cid];
}
if(this.views&&_21.views[_22]){
var _24=_21.views[_22];
if(!_24.dependencies){
_24.dependencies=[];
}
var _25=_24.template?_24.dependencies.concat(["dojo/text!app/"+_24.template]):_24.dependencies.concat([]);
var def=new _4();
if(_25.length>0){
require(_25,function(){
def.resolve.call(def,arguments);
});
}else{
def.resolve(true);
}
var _26=new _4();
_4.when(def,function(){
var _27;
if(_24.type){
_27=_1.getObject(_24.type);
}else{
if(_21.defaultViewType){
_27=_21.defaultViewType;
}else{
throw Error("Unable to find appropriate ctor for the base child class");
}
}
var _28=_1.mixin({},_24,{id:_21.id+"_"+_22,templateString:_24.template?arguments[0][arguments[0].length-1]:"<div></div>",parent:_21,app:_21.app});
if(_23){
_28.defaultView=_23;
}
var _29=new _27(_28);
if(!_29.loadedModels){
_29.loadedModels=_14(_24.models,_21.loadedModels);
_16([_29],_29.loadedModels);
}
var _2a=_21.addChild(_29);
var _2b;
_23=_23.split(",");
if((_23[0].length>0)&&(_23.length>1)){
_2b=_21.loadChild(_29,_23[0],_23[1]);
}else{
if(_23[0].length>0){
_2b=_21.loadChild(_29,_23[0],"");
}
}
_1.when(_2b,function(){
_26.resolve(_2a);
});
});
return _26;
}
throw Error("Child '"+_22+"' not found.");
},resize:function(_2c,_2d){
var _2e=this.domNode;
if(_2c){
_8.setMarginBox(_2e,_2c);
if(_2c.t){
_2e.style.top=_2c.t+"px";
}
if(_2c.l){
_2e.style.left=_2c.l+"px";
}
}
var mb=_2d||{};
_1.mixin(mb,_2c||{});
if(!("h" in mb)||!("w" in mb)){
mb=_1.mixin(_8.getMarginBox(_2e),mb);
}
var cs=_7.getComputedStyle(_2e);
var me=_8.getMarginExtents(_2e,cs);
var be=_8.getBorderExtents(_2e,cs);
var bb=(this._borderBox={w:mb.w-(me.w+be.w),h:mb.h-(me.h+be.h)});
var pe=_8.getPadExtents(_2e,cs);
this._contentBox={l:_7.toPixelValue(_2e,cs.paddingLeft),t:_7.toPixelValue(_2e,cs.paddingTop),w:bb.w-pe.w,h:bb.h-pe.h};
this.layout();
},layout:function(){
var _2f,_30,_31;
if(this.selectedChild&&this.selectedChild.isFullScreen){
console.warn("fullscreen sceen layout");
}else{
_30=_c("> [region]",this.domNode).map(function(_32){
var w=_d.getEnclosingWidget(_32);
if(w){
return w;
}
return {domNode:_32,region:_b.get(_32,"region")};
});
if(this.selectedChild){
_30=_3.filter(_30,function(c){
if(c.region=="center"&&this.selectedChild&&this.selectedChild.domNode!==c.domNode){
_7.set(c.domNode,"z-index",25);
_7.set(c.domNode,"display","none");
return false;
}else{
if(c.region!="center"){
_7.set(c.domNode,"display","");
_7.set(c.domNode,"z-index",100);
}
}
return c.domNode&&c.region;
},this);
}else{
_3.forEach(_30,function(c){
if(c&&c.domNode&&c.region=="center"){
_7.set(c.domNode,"z-index",25);
_7.set(c.domNode,"display","none");
}
});
}
}
this.layoutChildren(this.domNode,this._contentBox,_30);
_3.forEach(this.getChildren(),function(_33){
if(!_33._started&&_33.startup){
_33.startup();
}
});
},layoutChildren:function(_34,dim,_35,_36,_37){
dim=_1.mixin({},dim);
_9.add(_34,"dijitLayoutContainer");
_35=_3.filter(_35,function(_38){
return _38.region!="center"&&_38.layoutAlign!="client";
}).concat(_3.filter(_35,function(_39){
return _39.region=="center"||_39.layoutAlign=="client";
}));
_3.forEach(_35,function(_3a){
var elm=_3a.domNode,pos=(_3a.region||_3a.layoutAlign);
var _3b=elm.style;
_3b.left=dim.l+"px";
_3b.top=dim.t+"px";
_3b.position="absolute";
_9.add(elm,"dijitAlign"+_19(pos));
var _3c={};
if(_36&&_36==_3a.id){
_3c[_3a.region=="top"||_3a.region=="bottom"?"h":"w"]=_37;
}
if(pos=="top"||pos=="bottom"){
_3c.w=dim.w;
_1b(_3a,_3c);
dim.h-=_3a.h;
if(pos=="top"){
dim.t+=_3a.h;
}else{
_3b.top=dim.t+dim.h+"px";
}
}else{
if(pos=="left"||pos=="right"){
_3c.h=dim.h;
_1b(_3a,_3c);
dim.w-=_3a.w;
if(pos=="left"){
dim.l+=_3a.w;
}else{
_3b.left=dim.l+dim.w+"px";
}
}else{
if(pos=="client"||pos=="center"){
_1b(_3a,dim);
}
}
}
});
},getChildren:function(){
return this._supportingWidgets;
},startup:function(){
if(this._started){
return;
}
this._started=true;
var _3d=this.defaultView?this.defaultView.split(","):"default";
toId=_3d.shift();
_3e=_3d.join(",");
var _3e;
if(this.views[this.defaultView]&&this.views[this.defaultView]["defaultView"]){
_3e=this.views[this.defaultView]["defaultView"];
}
if(this.models&&!this.loadedModels){
this.loadedModels=_14(this.models);
_16(this.getChildren(),this.loadedModels);
}
var _3f=this.loadChild(this,toId,_3e);
_4.when(_3f,_5.hitch(this,function(_40){
this.set("selectedChild",_40);
var _41=this.getParent&&this.getParent();
if(!(_41&&_41.isLayoutContainer)){
this.resize();
this.connect(_6("ie")?this.domNode:_1.global,"onresize",function(){
this.resize();
});
}
_3.forEach(this.getChildren(),function(_42){
_42.startup();
});
if(this._startView!=this.defaultView){
this.transition(this._startView,{});
}
}));
},addChild:function(_43){
_9.add(_43.domNode,this.baseClass+"_child");
_43.region="center";
_b.set(_43.domNode,"region","center");
this._supportingWidgets.push(_43);
_a.place(_43.domNode,this.domNode);
this.children[_43.id]=_43;
return _43;
},removeChild:function(_44){
if(_44){
var _45=_44.domNode;
if(_45&&_45.parentNode){
_45.parentNode.removeChild(_45);
}
return _44;
}
},_setSelectedChildAttr:function(_46,_47){
if(_46!==this.selectedChild){
return _4.when(_46,_5.hitch(this,function(_48){
if(this.selectedChild){
if(this.selectedChild.deactivate){
this.selectedChild.deactivate();
}
_7.set(this.selectedChild.domNode,"zIndex",25);
}
this.selectedChild=_48;
_7.set(_48.domNode,"display","");
_7.set(_48.domNode,"zIndex",50);
this.selectedChild=_48;
if(this._started){
if(_48.startup&&!_48._started){
_48.startup();
}else{
if(_48.activate){
_48.activate();
}
}
}
this.layout();
}));
}
},transition:function(_49,_4a){
var _4b,_4c,_4d,_4e=this.selectedChild;
if(_49){
var _4f=_49.split(",");
_4b=_4f.shift();
_4c=_4f.join(",");
}else{
_4b=this.defaultView;
if(this.views[this.defaultView]&&this.views[this.defaultView]["defaultView"]){
_4c=this.views[this.defaultView]["defaultView"];
}
}
_4d=this.loadChild(this,_4b,_4c);
if(!_4e){
return this.set("selectedChild",_4d);
}
var _50=new _4();
_4.when(_4d,_5.hitch(this,function(_51){
var _52;
if(_51!==_4e){
var _53=_13.getWaitingList([_51.domNode,_4e.domNode]);
var _54={};
_54[_4e.domNode.id]=_13.playing[_4e.domNode.id]=new _4();
_54[_51.domNode.id]=_13.playing[_4e.domNode.id]=new _4();
_4.when(_53,_1.hitch(this,function(){
this.set("selectedChild",_51);
_12(_4e.domNode,_51.domNode,_1.mixin({},_4a,{transition:this.defaultTransition||"none",transitionDefs:_54})).then(_5.hitch(this,function(){
if(_4b&&_51.transition){
_52=_51.transition(_4c,_4a);
}
_4.when(_52,function(){
_50.resolve();
});
}));
}));
return _50;
}
if(_4c&&_51.transition){
_52=_51.transition(_4c,_4a);
}
_4.when(_52,function(){
_50.resolve();
});
return _50;
}));
return _50;
},toString:function(){
return this.id;
},activate:function(){
},deactive:function(){
}});
});
