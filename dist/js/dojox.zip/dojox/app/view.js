//>>built
define("dojox/app/view",["dojo/_base/declare","dijit/_WidgetBase","dijit/_Container","dijit/_Contained","dijit/_TemplatedMixin","dijit/_WidgetsInTemplateMixin"],function(_1,_2,_3,_4,_5,_6){
return _1("dojox.app.view",[_2,_5,_3,_4,_6],{selected:false,keepScrollPosition:true,baseClass:"applicationView mblView",config:null,widgetsInTemplate:true,templateString:"<div></div>",toString:function(){
return this.id;
},activate:function(){
},deactivate:function(){
},getParent:function(){
return null;
}});
});
