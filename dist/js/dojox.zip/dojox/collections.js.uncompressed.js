//>>built
define("dojox/collections", ["./collections/_base"], function(collections){
	return collections;
});
