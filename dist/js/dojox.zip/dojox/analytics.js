//>>built
define("dojox/analytics",["./analytics/_base"],function(_1){
return _1;
});
