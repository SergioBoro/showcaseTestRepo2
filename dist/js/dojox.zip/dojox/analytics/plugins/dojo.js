//>>built
define("dojox/analytics/plugins/dojo",["dojo/_base/kernel","dojo/_base/lang","../_base"],function(_1,_2,_3){
var _4=_1.getObject("dojox.analytics.plugins",true);
_4.dojo=new (function(){
this.addData=_1.hitch(_3,"addData","dojo");
_1.addOnLoad(_1.hitch(this,function(){
var _5={};
for(var i in _1){
if((i=="version")||((!_1.isObject(_1[i]))&&(i[0]!="_"))){
_5[i]=_1[i];
}
}
if(_1.config){
_5.djConfig=_1.config;
}
this.addData(_5);
}));
})();
return _4.dojo;
});
