def d():
    def e():
        pass