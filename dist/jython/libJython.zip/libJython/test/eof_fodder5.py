def f():
    pass
# just a comment