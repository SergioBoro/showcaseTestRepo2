def f():
    def g():
        pass
        
