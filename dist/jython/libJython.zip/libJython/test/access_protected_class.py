from java.awt.geom import Ellipse2D, EllipseIterator
EllipseIterator(Ellipse2D.Float(), None)
